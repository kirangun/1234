package com.cg.beans;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {

	public static void main(String[] args) {
		Resource rsc = new ClassPathResource("beans.xml");
		BeanFactory factory = new XmlBeanFactory(rsc);
		Employee emp = (Employee) factory.getBean("e1");
		Employee emp1 = (Employee) factory.getBean("e2");
		//Employee emp2 = (Employee) factory.getBean("e3");
		/*emp.setEmpid(111);
		emp.setName("Kiran");
		emp.setLocation("Hyderabad");
		emp.setSalary(5555);*/
		System.out.println(emp);
		System.out.println(emp1);
		//System.out.println(emp2);
		
	}

}
