package com.cg.beans;

import java.time.LocalDate;

public class Employee {
	private int empid;
	private String name;
	private String location;
	private double salary;
	private LocalDate joinDate;
	
	
	public Employee() {
		super();
	}
	
	public Employee(int empid, String name, String location, double salary) {
		super();
		this.empid = empid;
		this.name = name;
		this.location = location;
		this.salary = salary;
	}

	public Employee(int empid, String name, String location, double salary, LocalDate joinDate) {
		super();
		this.empid = empid;
		this.name = name;
		this.location = location;
		this.salary = salary;
		this.joinDate = joinDate;
	}

	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", location=" + location + ", salary=" + salary
				+ ", joinDate=" + joinDate + "]";
	}
	
}
