package lab11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Excercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ExecutorService executor=Executors.newFixedThreadPool(1);
		 Runnable work=new RefreshThread();
		 executor.execute(work);
	}

}
