package lab11;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FileProgram {
	public FileProgram() throws IOException {

		 BufferedReader br = new BufferedReader(

		  new FileReader("D:\\Lab Assignments\\Module1\\src\\lab10\\source.txt"));

		 BufferedWriter bw = new BufferedWriter(

		  new FileWriter("D:\\Lab Assignments\\Module1\\src\\lab10\\target.txt"));

		 ExecutorService executor=Executors.newFixedThreadPool(1);
		 Runnable work=new CopyDataThread(br, bw);
		 executor.execute(work);

		 }
}
