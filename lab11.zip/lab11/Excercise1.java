package lab11;

import java.io.IOException;

public class Excercise1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		@SuppressWarnings("unused")

		FileProgram f = new FileProgram();

	}

}

