import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

public class Test5 {

	public static void main(String[] args) {
		String ar[]= {"Hello","Spring","Welcome","Capgemini"};
		Stream<String> stream = Stream.of(ar);
		Stream<String> stream1 = stream.filter((str)->str.length()>5);
		stream1.forEach(System.out::println);
		
	}

}
