import java.util.HashSet;
import java.util.Set;

public class Test {

	public static void main(String[] args) {
			Set hs = new HashSet();
			hs.add(1);
			hs.add(null);
			hs.add(null);
			hs.add("1");
			System.out.println(hs);
	}
}
