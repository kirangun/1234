interface TestInf
{
	int i=10;
}
public class TestInterface {

	public static void main(String[] args) {
		TestInf.i=12;
		System.out.println("I:"+TestInf.i);
	}

}
