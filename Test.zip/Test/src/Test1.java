import java.util.TreeSet;

public class Test1 {
	public static void main(String[] args) {
		/*
		 * BiFunction<String, String, String>fun =(str1,str2)->str1+str2; String
		 * result=null; result=fun.apply("10", "20"); System.out.println(result);
		 */

		TreeSet<Integer> intSet = new TreeSet<Integer>();
		intSet.add(new Integer(10));
		intSet.add(11);
		intSet.add(new Integer(10));
		intSet.add(new Integer(10));
		intSet.add(new Integer(10));
		System.out.println(intSet);

		/*
		 * String str1 = new String("Capgemini"); String str2 = "Capgemini"; String str3
		 * = new String("Capgemini"); String str4 = "Capgemini"; String str5 = "";
		 * String str6 = "";
		 * 
		 * System.out.println("Is str1=str?" + str1.equals(str2));
		 * System.out.println("Is str1=str?" + str1.equals(str3));
		 * System.out.println("Is str1=str?" + str1.equals(str3));
		 * System.out.println("is" + str2 == str4); System.out.println(str2.hashCode());
		 * System.out.println(str4.hashCode()); System.out.println(str5.hashCode());
		 * System.out.println("is" + str5.equals(str6));
		 */
		TreeSet<Emp> EmpSet = new TreeSet<Emp>();
		EmpSet.add(new Emp(88, "Kiran"));
		EmpSet.add(new Emp(855, "Kisrsan"));
		EmpSet.add(new Emp(889, "Kirsan"));
		EmpSet.add(new Emp(8844, "Kirasn"));
		EmpSet.add(new Emp(818, "Kiranss"));
		EmpSet.add(new Emp(1188, "Kirans"));
		EmpSet.add(new Emp(8338, "Kirana"));
		System.out.println(EmpSet							);

	}
}
