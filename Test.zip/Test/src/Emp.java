
public class Emp implements Comparable<Emp> {
	int id;
	String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Emp(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	public int compareTo(Emp o) 
	{
		if(this.id>o.id)
		{
			return 1;
		}
		else if(this.id<o.id)
		{
		return -1;
		}
		else
			return 0;
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + "]";
	}

}
