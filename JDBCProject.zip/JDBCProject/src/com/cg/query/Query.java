package com.cg.query;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.db.Database;

public class Query {

	public static List<String> getTitle(int id) throws IOException, SQLException {
		List<String> list = new ArrayList<>();
		String sql = "select * from book,book_author,author where book_author.id=?";
		Connection con = Database.getConnection();
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, id);
		ResultSet set = stmt.executeQuery();
		while (set.next()) {
			list.add(set.getString(2));
			list.add(set.getString(3));
			list.add(set.getString(7));
		}
		return list;
	}

	public static int insertAuthor(String author, String phonenumber)
			throws FileNotFoundException, IOException, SQLException {
		String sql = "Insert into author values(?,?,?)";
		Connection con = Database.getConnection();
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1,generateId());
		stmt.setString(2, author);
		stmt.setString(3, phonenumber);
		int update = stmt.executeUpdate();
		return update;
	}

	public static int generateId() throws FileNotFoundException, IOException, SQLException {
		int id = 0;
		String sql = "Select author_id_seq.nextval from dual";
		Connection con = Database.getConnection();
		Statement stmt = con.createStatement();
		ResultSet set = stmt.executeQuery(sql);
		while (set.next()) {
			id = set.getInt(1);
		}
		return id;

	}

	public static int deleteAuthor(int id) throws FileNotFoundException, IOException, SQLException {
		String sql = "Delete from author where id=?";
		Connection con = Database.getConnection();
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, id);
		int update = stmt.executeUpdate();
		return update;
	}

	public static List<String> getAuthorList() throws SQLException, FileNotFoundException, IOException {
		List<String> list = new ArrayList<>();
		String sql = "select * from author";
		Connection con = Database.getConnection();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet set = stmt.executeQuery();
		while (set.next()) {
			String s = set.getString(1) + "   " + set.getString(2) + "  " + set.getString(3);
			list.add(s);
		}
		return list;
	}
}
