package com.cg.db;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Database {

	public static Connection getConnection() throws FileNotFoundException, IOException {
		String driver;
		String url;
		String user;
		String password;
		Connection con = null;
		try (FileInputStream fis = new FileInputStream(
				"D:\\MyData\\MySpringProjects\\JDBCProject\\Resource\\dbvalues.properties")) {
			Properties p = new Properties();
			p.load(fis);
			driver = p.getProperty("driver");
			url = p.getProperty("url");
			user = p.getProperty("user");
			password = p.getProperty("password");
			// loading the driver
			Class.forName(driver);
			// establishing the connection with database
			con = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException | SQLException e) {
			System.err.println("connection  is not established successfully");
			e.printStackTrace();
		}
		return con;
	}

}
