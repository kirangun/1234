package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;

import com.cg.demo.bin.Author;
import com.cg.demo.bin.Book;
import com.cg.demo.dao.AuthorDaoImpl;



public class TestProductOrderDemo {

	public static void main(String[] args)
	{
		AuthorDaoImpl adi=new AuthorDaoImpl();
		Scanner sc=new Scanner(System.in);
		int opt;
do
{
	Book bk=new Book();
	System.out.println("1.add books\n2.query all books\n3.query all books for given author name\n4.list all books in given range\n5.list author name based on author id\n6.exit");
	System.out.println("enter option");
	opt=sc.nextInt();
	switch(opt)
	{
	case 1:
		
		bk.setPrice(500);
		bk.setTitle("abc");	
		Book bk1=new Book();
		bk1.setPrice(400);
		bk1.setTitle("wxy");	
		HashSet<Book> proSet=new HashSet();
		proSet.add(bk);
		proSet.add(bk1);
		Author at=new Author();
		at.setName("java");
		at.setBookSet(proSet);
		adi.add(at);
		break;
	case 2:
		ArrayList<Author> a1=adi.getAllOrders3();		
		System.out.println(a1);
		break;
	case 3:
		ArrayList<Author> a=adi.getAllOrders();		
		System.out.println(a);
		break;
	case 4:
		
		ArrayList<Book> at1=adi.getAllOrders1();		
		System.out.println(at1);
		break;
	case 5:
		
		ArrayList<Author> at2=adi.getAllOrders2();		
		System.out.println(at2);
		break;
	case 6:
		System.exit(5);
	}
	}while(opt!=5);

	}

}
