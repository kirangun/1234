package com.cg.demo.dao;


import java.util.ArrayList;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.demo.bin.Author;
import com.cg.demo.bin.Book;
import com.cg.demo.util.JPAUtil;

public class AuthorDaoImpl 
{
	EntityManager em=null;
	EntityTransaction tran=null;
	Scanner sc=new Scanner(System.in);
	public AuthorDaoImpl()
	{
		em=JPAUtil.getEntityManager();
		tran=em.getTransaction();
		
	}
	public void add(Author order)
	{
	
		tran.begin();
		em.persist(order);
		tran.commit();
		System.out.println("order info is inserted");
	
    }
	public ArrayList<Author> getAllOrders()
	{
		System.out.println("enter name");
		String nm=sc.next();
		TypedQuery<Author> tq=em.createQuery("select auths from Author auths where name='"+nm+"'",Author.class);
		ArrayList ordList=(ArrayList) tq.getResultList();
		return ordList;
		
	}
	public ArrayList<Book> getAllOrders1()
	{
		TypedQuery<Book> tq=em.createQuery("select books from Book books where price>=500 and price<=1000",Book.class);
		ArrayList ordList=(ArrayList) tq.getResultList();
		return ordList;
		
	}
	public ArrayList<Author> getAllOrders2() 
	{
		System.out.println("enter id");
		int id=sc.nextInt();
		Query query1 =em.createQuery("select auth.name from Author auth where Id='"+id+"'",Author.class);
		ArrayList result = (ArrayList) query1.getResultList();
		return result;
	}
	public ArrayList<Author> getAllOrders3() {
		
		TypedQuery<Author> tq=em.createQuery("select auths from Author auths",Author.class);
		ArrayList ordList=(ArrayList) tq.getResultList();
		return ordList;
		
	}
	
	
}
