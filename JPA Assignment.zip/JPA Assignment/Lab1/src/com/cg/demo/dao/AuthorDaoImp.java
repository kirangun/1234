package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.demo.bin.Author;
import com.cg.demo.bin.Author;
import com.cg.demo.util.JPAUtil;

public class AuthorDaoImp implements IAuthorDao
{

	EntityManager em=null;
	EntityTransaction tran=null;
	public AuthorDaoImp()
	{
		
		
	}
	@Override
	public Author addAuthor(Author e)
	{
		em=JPAUtil.getEntityManager();
		tran=em.getTransaction();
		tran.begin();
		em.persist(e);
		tran.commit();
		System.out.println("data is inserted");
		Author e1=em.find(Author.class,e.getAuthorId());
	
		return e1;
	}

	public Author daleteAuthorById(int authorId) {
		
		em=JPAUtil.getEntityManager();
		Author e1=em.find(Author.class,authorId);
		tran=em.getTransaction();
		tran.begin();
		em.remove(e1);
		tran.commit();
		return e1;
	}
	@Override
	public ArrayList<Author> fetctAllAuthor()
	{
		String myQry="select auths from Author auths";
		em=JPAUtil.getEntityManager();
		TypedQuery<Author> tyQry=em.createQuery(myQry,Author.class);
		ArrayList<Author> selQry=(ArrayList<Author>) tyQry.getResultList();
		return selQry;
		
	}
	@Override
	public Author updateAuthor(int authorId, String no) {
		
		em=JPAUtil.getEntityManager();
		tran=em.getTransaction();
		Author auth1=em.find(Author.class,authorId);
		auth1.setPhoneNo(no);
		tran.begin();
		em.merge(auth1);
		tran.commit();
		System.out.println("number is updated for:"+auth1);
		return auth1;
	}

	


}
