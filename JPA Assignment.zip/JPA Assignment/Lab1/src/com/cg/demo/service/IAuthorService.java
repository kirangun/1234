package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bin.Author;
import com.cg.demo.bin.Author;

public interface IAuthorService 
{
	public Author addAuthor(Author e);
	public Author deleteAuthorById(int authorId);
	public ArrayList<Author> fetctAllAuthor();
	public Author updateAuthor(int authorId,String no);
}
