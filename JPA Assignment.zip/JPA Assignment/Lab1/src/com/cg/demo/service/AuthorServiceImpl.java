package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bin.Author;
import com.cg.demo.dao.AuthorDaoImp;
import com.cg.demo.dao.IAuthorDao;

public class AuthorServiceImpl implements IAuthorService
{
	AuthorDaoImp authDao=null;
	public AuthorServiceImpl()
	{
		authDao=new AuthorDaoImp();
	}

	@Override
	public Author addAuthor(Author e)
	{                                                                                                  
		
		return authDao.addAuthor(e);
	}


	

	@Override
	public ArrayList<Author> fetctAllAuthor() {
	
		return authDao.fetctAllAuthor();
	}

	public Author updateAuthor(int authorId, String no) {
		// TODO Auto-generated method stub
		return authDao.updateAuthor(authorId, no);
	}

	@Override
	public Author deleteAuthorById(int authorId) {
		
		return authDao.daleteAuthorById(authorId);
	}

	
	

	

}
