package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.demo.bin.Author;
import com.cg.demo.service.AuthorServiceImpl;
import com.cg.demo.service.IAuthorService;

public class TestEmpOp {

	public static void main(String[] args)
	{
		IAuthorService empSer =new AuthorServiceImpl();
		Scanner sc=new Scanner(System.in);
		int ch;
		do {
			Author a=new Author();
			System.out.println("enter choice");
			System.out.println("1.insert author\n2.delete author\n3.select\n4.update author\n5.exit");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
			System.out.println("enter fname,mname,lastname phoneno");
			String fnm=sc.next();
			String mnm=sc.next();
			String lnm=sc.next();
			String pno=sc.next();
			a.setFirstName(fnm);
			a.setMiddleName(mnm);
			a.setLastName(lnm);
			a.setPhoneNo(pno);
			Author aa=empSer.addAuthor(a);
			System.out.println(aa.getAuthorId()+"added");
			break;
			case 2:
				System.out.println("enter author id");
				int aid1=sc.nextInt();
				Author a1=empSer.deleteAuthorById(aid1);
				System.out.println(a1.getAuthorId()+"deleted");
				break;
			case 3:
				ArrayList<Author> a2=empSer.fetctAllAuthor();
				System.out.println(a2);
				break;
			case 4:
				System.out.println("enter author id");
				int aid3=sc.nextInt();
				Author a11=empSer.updateAuthor(aid3,"77762598");
				System.out.println(a11.getAuthorId()+"no is updated");
				System.out.println("hi:");
			case 5:
				System.exit(1);
				
				
				
			}
			
		}while(ch!=4);
	

	}

}
