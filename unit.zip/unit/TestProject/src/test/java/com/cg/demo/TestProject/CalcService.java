package com.cg.demo.TestProject;

import com.cg.demo.AddService;

public class CalcService {

	public CalcService(AddService addService) {
		// TODO Auto-generated constructor stub
	}

	public int calc(int num1, int num2) {
		return num1 + num2;
	}

}
