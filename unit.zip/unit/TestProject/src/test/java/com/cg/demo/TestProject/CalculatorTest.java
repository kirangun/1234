package com.cg.demo.TestProject;

import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CalculatorTest {
	
	@Mock
	Calculator c;
	@Mock
	Validator validate;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		c = new Calculator();
	}

	@Test
	public void testAdd() {
		Assert.assertEquals("add", 10, c.add(5, 5));
	}

	@Test
	public void testSub() {
		Assert.assertEquals("substract", 2, c.sub(5, 3));
	}

	@Test
	public void testMul() {
		int expected = 56;
		Assert.assertEquals("multiply", expected, c.mul(7, 8));
	}

	@Test
	public void testAdd_negativeNumbers_shouldThrowException() {
		int expected = 1, i = 7, j = 7;
		when(validate.validateDenominator(i, j)).thenReturn(true);
		Assert.assertEquals("multiply", expected, c.div(7, 7));
	}

	@After
	public void tearDown() {
		c = null;
	}
}
