package com.cg.demo.TestProject;

public class Validator {

	public boolean validateNumber(int i, int j) {
		if (j != 0)
			return true;
		else
			return false;
	}

	public boolean validateDenominator(int i, int j) {
		if (j != 0)
			return true;
		else
			return false;
	}

}
