package com.cg.demo.TestProject;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class Calculator {
	@InjectMocks 
	Validator validate = new Validator();

	public int add(int i, int j) {
		validate.validateNumber(i, j);
		return i + j;
	}

	public int sub(int i, int j) {
		return i - j;
	}

	public int mul(int i, int j) {
		return i * j;
	}

	public int div(int i, int j) {
		Mockito.mock(Validator.class);
		boolean denominator = validate.validateDenominator(i, j);
		if (denominator == false)
			throw new ArithmeticException("Denominator should not be zero");
		return i / j;
	}
}
