package com.cg.demo.Port;

public interface StockService {
	public double getPrice(Stock stock);
}
