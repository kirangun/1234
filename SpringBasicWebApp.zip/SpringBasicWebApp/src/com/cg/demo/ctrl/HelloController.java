package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/helloCtrl")
public class HelloController {
	@RequestMapping("/ShowHomepage")
	/*public ModelAndView dispHomePage()
	{
		String today = "Today is:"+LocalDate.now();
		return new ModelAndView("Home","todayObj",today);
				
	}*/
	
	public String dispHomePage(Model model)
	{
		String today = "Today is:"+LocalDate.now();
		model.addAttribute("todayObj",today);
		return "Home";
		
	}
	@RequestMapping("/ShowGreetmePage")
	public String dispGreetPage()
	{
		return "GreetMe";
	}
	
}

