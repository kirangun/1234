package com.cg.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.demo.bean.Address;
import com.cg.demo.bean.Stud;
import com.cg.demo.util.JPAUtil;

public class StudentDaoImpl {
	EntityManager em = null;
	EntityTransaction trans = null;
	public StudentDaoImpl() {
		
	}
	public Stud addStudent(Stud stu) {
		em=JPAUtil.getEntityManager();
		trans=em.getTransaction();
		trans.begin();
		em.persist(stu);
		trans.commit();
		Stud st=em.find(Stud.class, stu.getRollNo());
		return st;
	}
	public Stud delStu(int rn) {
		em=JPAUtil.getEntityManager();
		trans=em.getTransaction();
		Stud st=em.find(Stud.class, rn);
		trans.begin();
		em.remove(st);
		trans.commit();
		Stud deletedStu=em.find(Stud.class, rn);
		return deletedStu;
	}
	public Address delAddress(int addId) {
		em=JPAUtil.getEntityManager();
		trans=em.getTransaction();
		Address ad=em.find(Address.class, addId);
		trans.begin();
		em.remove(ad);
		trans.commit();
		Address deletedAdd=em.find(Address.class, addId);
		return deletedAdd;
	}
}
