package com.cg.demo.ui;

import java.util.Scanner;

import com.cg.demo.bean.Address;
import com.cg.demo.bean.Stud;
import com.cg.demo.dao.StudentDaoImpl;

public class TestStuDemo {

	public static void main(String[] args) {
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name:");
		String nm =sc.next();
		System.out.println("Enter Street:");
		String st =sc.next();
		System.out.println("Enter City:");
		String ct =sc.next();
		System.out.println("Enter State:");
		String sta =sc.next();
		System.out.println("Enter Zipcode:");
		String zp =sc.next();
		Address ad1 = new Address(st,ct,sta,zp);
		Stud st1 = new Stud(nm,ad1);
		
		Stud tempSt =stuDao.addStudent(st1);
		System.out.println("Data Added " +tempSt);*/
		
		StudentDaoImpl stuDao = new StudentDaoImpl();
		System.out.println("Delete based on roll No");
		Stud tempSt2 = stuDao.delStu(38);
		if(tempSt2==null)
		{	
			System.out.println("Data is Deleted");
		}
		else {
			System.out.println("Data is not Deleted");
		}
		}
	}


