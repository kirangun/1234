package com.cg.demo.ui;

import java.util.Date;
import java.util.HashSet;

import com.cg.demo.bean.Order;
import com.cg.demo.bean.Product;
import com.cg.demo.dao.ProductDaoImpl;

public class TestProdOrdDemo {

	public static void main(String[] args) {
		
		Product elecProduct = new Product();
		elecProduct.setProductName("LED TV");
		elecProduct.setProductPrice(45000);
		
		Product beautyProduct = new Product();
		beautyProduct.setProductName("Face Wash");
		beautyProduct.setProductPrice(100);
		
		Product babyProduct = new Product();
		babyProduct.setProductName("Woodwards");
		babyProduct.setProductPrice(45);
		
		Product eleProduct = new Product();
		eleProduct.setProductName("CFL Bulb");
		eleProduct.setProductPrice(250);
		
		
		Order firstOrder = new Order();
		HashSet<Product> firstOrderProdSet= new HashSet<>();
		firstOrderProdSet.add(elecProduct);
		firstOrderProdSet.add(babyProduct);
		firstOrderProdSet.add(beautyProduct);
		firstOrder.setOrderDate(new Date());
		firstOrder.setProductSet(firstOrderProdSet);
		
		
		ProductDaoImpl dao = new ProductDaoImpl();
		dao.addOrder(firstOrder);
		
		
		Order secondOrder = new Order();
		HashSet<Product> secondOrderProdSet= new HashSet<>();
		secondOrderProdSet.add(elecProduct);
		secondOrderProdSet.add(babyProduct);
		secondOrderProdSet.add(eleProduct);
		secondOrder.setOrderDate(new Date());
		secondOrder.setProductSet(firstOrderProdSet);
		dao.addOrder(secondOrder);
	}

}
