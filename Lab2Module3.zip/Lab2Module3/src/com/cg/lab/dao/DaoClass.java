package com.cg.lab.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;

@Repository
@Transactional
public class DaoClass implements IDaoClass {

	@PersistenceContext
	EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	public Login getUser(Login login) {
		Login user = em.find(Login.class, login.getUsername());
		return user;
	}

	@Override
	public void addTrainee(Trainee trainee) {
		em.persist(trainee);
	}

	@Override
	public ArrayList<Trainee> getTrainees() {
		ArrayList<Trainee> list = (ArrayList<Trainee>) em.createQuery("from Trainee", Trainee.class).getResultList();
		return list;
	}

	@Override
	public Trainee deleteTrainee(Trainee trainee) {
		trainee = em.find(Trainee.class, trainee.getTraineeId());
		em.remove(trainee);
		return trainee;
	}
	@Override
	public Trainee getTrainee(Trainee trainee) {
		return em.find(Trainee.class, trainee.getTraineeId());
	}

	@Override
	public Trainee modifyTrainee(Trainee trainee) {
		em.merge(trainee);
		return trainee;
	}

}
