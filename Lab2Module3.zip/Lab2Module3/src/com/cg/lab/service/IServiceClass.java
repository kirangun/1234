package com.cg.lab.service;

import java.util.ArrayList;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;

public interface IServiceClass {

	boolean validateUser(Login login);

	void addTrainee(Trainee trainee);

	ArrayList<Trainee> getTrainees();

	Trainee deleteTrainee(Trainee trainee);

	Trainee modifyTrainee(Trainee trainee);

	Trainee getTrainee(Trainee trainee);
	
}
