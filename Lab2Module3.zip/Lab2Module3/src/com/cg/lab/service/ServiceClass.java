package com.cg.lab.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;
import com.cg.lab.dao.IDaoClass;

@Service
public class ServiceClass implements IServiceClass {

	@Autowired
	IDaoClass dao;

	public IDaoClass getDao() {
		return dao;
	}

	public void setDao(IDaoClass dao) {
		this.dao = dao;
	}

	public boolean validateUser(Login login) {
		Login user = dao.getUser(login);
		if (user == null) {
			return false;
		}
		if (user.getPassword().equals(login.getPassword())) {
			return true;
		} else
			return false;
	}

	@Override
	public void addTrainee(Trainee trainee) {
		dao.addTrainee(trainee);
	}

	@Override
	public ArrayList<Trainee> getTrainees() {
		return dao.getTrainees();
	}

	@Override
	public Trainee deleteTrainee(Trainee trainee) {
		return dao.deleteTrainee(trainee);
	}

	@Override
	public Trainee modifyTrainee(Trainee trainee) {
		return dao.modifyTrainee(trainee);
	}

	@Override
	public Trainee getTrainee(Trainee trainee) {
		return dao.getTrainee(trainee);
	}
}
