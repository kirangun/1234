package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Address;
import com.cg.bean.Customer;
import com.cg.service.ServiceInterface;

@Controller
public class RegisterController {
	@Autowired
	ServiceInterface service;

	public ServiceInterface getService() {
		return service;
	}

	public void setService(ServiceInterface service) {
		this.service = service;
	}

	@RequestMapping("/showRegister")
	public String showLogin(Model model) {
		Customer customer = new Customer();
		model.addAttribute(customer);
		Address address = new Address();
		model.addAttribute("address", address);
		return "register";
	}

	@RequestMapping("/ValidateUser")
	public String validate(@ModelAttribute("customer") Customer customer, @ModelAttribute("address") Address address,
			Model model) {
		int accno = 0;
		customer.setAddress(address);
		accno = service.addCustomer(customer);
		model.addAttribute("accno", accno);
		model.addAttribute("customer", customer);
		return "success";
	}
}
