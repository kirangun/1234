package com.cg.demo.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "students2")
public class Stud {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "studentId", length = 10)
	private int rollNo;
	@Column(name = "name", length = 20)
	private String stuName;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Address> addresses;

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	@Override
	public String toString() {
		return "Stud [rollNo=" + rollNo + ", stuName=" + stuName + "]";
	}

	public Stud() {
		super();
	}

}
