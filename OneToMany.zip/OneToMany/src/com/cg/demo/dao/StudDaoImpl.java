package com.cg.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.demo.bean.Stud;
import com.cg.demo.util.JPA;

public class StudDaoImpl {
	EntityManager em = null;
	EntityTransaction trans = null;
	public StudDaoImpl() {
		em=JPA.geEntityManager();
		trans=em.getTransaction();
	}
	public Stud addStudent(Stud st) {
		trans.begin();
		em.persist(st);
		trans.commit();
		em.find(Stud.class, st.getRollNo());
		return st;
	}
	
}
