package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.List;

import com.cg.demo.bean.Address;
import com.cg.demo.bean.Stud;
import com.cg.demo.dao.StudDaoImpl;

public class Test {

	public static void main(String[] args) {

		Address ad1 = new Address("hnk", "wgl", "tg", "566");
		Address ad2 = new Address("hnk2", "wgl2", "tg2", "5662");

		StudDaoImpl dao = new StudDaoImpl();
		Stud stud = new Stud();
		stud.setStuName("sdfs");
		List<Address> addresses = new ArrayList<>();
		addresses.add(ad1);
		addresses.add(ad2);
		stud.setAddresses(addresses);
		
		dao.addStudent(stud);

	}

}
