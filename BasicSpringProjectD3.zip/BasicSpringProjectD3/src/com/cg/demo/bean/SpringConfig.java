package com.cg.demo.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<String> getDepts()        //Func. will return the bean definition
	{
		ArrayList<String>depList= new ArrayList<>();
		depList.add("Java");
		depList.add("Oracle");
		depList.add("Testing");
		return depList;
		
	}
}
