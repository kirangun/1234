package com.cg.demo.ui;

import com.cg.demo.bean.Address;
import com.cg.demo.bean.Stud;
import com.cg.demo.dao.StudDaoImpl;

public class Test {

	public static void main(String[] args) {
		
		Address ad1 = new Address("hnk", "wgl", "tg", "566");
		Stud s1 = new Stud("Kiran", ad1);
		Stud s2 = new Stud("adfa", ad1);
		StudDaoImpl dao = new StudDaoImpl();
		dao.addStudent(s1);
		System.out.println("Data s1");
		dao.addStudent(s2);
		System.out.println("Data s2");
		
	
	}

}
