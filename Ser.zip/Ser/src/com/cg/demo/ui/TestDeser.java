package com.cg.demo.ui;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import com.cg.demo.bean.Employee;

public class TestDeser {
	public static void main(String[] args) {
		FileInputStream fis;
		try
		{
			fis=new FileInputStream("EmpInfo.txt");
			ObjectInputStream ois  = new ObjectInputStream(fis);
			Employee ee = (Employee)ois.readObject();
			System.out.println(ee);
			System.out.println("Annual Salary"+ee.getEmpSal());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
