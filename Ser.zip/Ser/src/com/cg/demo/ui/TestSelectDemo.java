package com.cg.demo.ui;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;


public class TestSelectDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g", "lab2etrg35", "lab2eoracle");
			String qry = "select * from employee";
			Statement st =con.createStatement();
			ResultSet rs = st.executeQuery(qry);
			ResultSetMetaData rmd = rs.getMetaData();
			int colCount = rmd.getColumnCount();
			System.out.println("ColumnCount"+colCount);
			
			for (int i = 1; i <= colCount; i++) {
				System.out.println(i+" "+"Col Name:"+rmd.getColumnLabel(i));
				System.out.println("col Type:"+rmd.getColumnTypeName(i));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		}	
	}
	
	

