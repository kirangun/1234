# SeedStack DDD sample 

SeedStack implementation of DDD sample app (https://github.com/citerus/dddsample-core).

## Run

    mvn seedstack:run

## Usage

The DDD sample doesn't contain any interface for now, so it cannot be externally tested.  

## Copyright and license

This source code is copyrighted by [The SeedStack Authors](https://github.com/seedstack/seedstack/blob/master/AUTHORS) and
released under the terms of the [Mozilla Public License 2.0](https://www.mozilla.org/MPL/2.0/). 
