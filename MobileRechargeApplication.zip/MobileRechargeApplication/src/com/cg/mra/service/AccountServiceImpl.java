package com.cg.mra.service;

import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MraException;

public class AccountServiceImpl implements AccountService {
	AccountDao dao = new AccountDaoImpl();


	@Override
	public Account getAccountDetails(String accId) throws MraException {
		return dao.getAccountDetails(accId);
	}


	@Override
	public int rechargeAccount(String accId, Double rechargeAmount) throws MraException {
		return dao.rechargeAccount(accId,rechargeAmount);
	}


	@Override
	public boolean validateAccountId(String accId) throws MraException {
		Boolean flag=true;
		if(!Pattern.matches("^[0-9]{3}$",accId))
		{
			flag=false;
			throw new MraException("Please Enter Valid AccountNumber \n eg:101");
			
		}
		return flag;
	}


	@Override
	public boolean validateRechargeAmount(Double rechargeAmount) throws MraException {
		Boolean flag=true;
		String str = Double.toString(rechargeAmount);
		if(!Pattern.matches("^[0-9.]{1,5}$",str))
		{
			flag=false;
			throw new MraException("Please Enter Valid Amount \n eg: Between 1 to 10000");
			
		}
		return flag;
	}

}
