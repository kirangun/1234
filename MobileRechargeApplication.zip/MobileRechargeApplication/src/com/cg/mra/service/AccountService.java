package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MraException;

public interface AccountService {

	Account getAccountDetails(String accId) throws MraException;

	int rechargeAccount(String accId, Double rechargeAmount) throws MraException;

	boolean validateAccountId(String accId) throws MraException;

	boolean validateRechargeAmount(Double rechargeAmount) throws MraException;

}
