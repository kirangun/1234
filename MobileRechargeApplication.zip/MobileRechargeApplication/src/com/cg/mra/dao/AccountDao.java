package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MraException;

public interface AccountDao {

	Account getAccountDetails(String accId) throws MraException;

	int rechargeAccount(String accId, Double rechargeAmount) throws MraException;

}
