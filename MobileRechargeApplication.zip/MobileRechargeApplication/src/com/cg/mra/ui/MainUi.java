package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MraException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUi {
	public static void main(String[] args) {
		AccountService service= new AccountServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1.Account Balance Enquiry");
			System.out.println("2.Recharge Account");
			System.out.println("3.Exit");
			System.out.println("Enter Choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter account id");
				String accId = sc.next();
				Account acc=null;
				try {
					if(service.validateAccountId(accId))
					 acc=service.getAccountDetails(accId);
					if(acc.getAccountId()==null)
						System.err.println("Given Account Doesn't exist");
					else
					System.out.println("Your Current balance is Rs. " + acc.getAccountBalance());
				} catch (MraException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter Account id");
				accId = sc.next();
				System.out.println("Enter Recharge Amount");
				Double rechargeAmount = sc.nextDouble();
				int i=0;
				try {
					
					if(service.validateRechargeAmount(rechargeAmount))
					 i= service.rechargeAccount(accId, rechargeAmount);
					if (i == 1) {
						System.out.println("Account Recharge Succesfully");
					}

				} catch (MraException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 3:
				System.exit(0);
				break;

			default:
				break;
			}
		} while (true);
		
	}
}
