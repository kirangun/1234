package com.cg.demo.ui;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.demo.bean.IGreet;

public class TestGreetDemo {

	public static void main(String[] args) {
		/*Resource res = new ClassPathResource("cg.xml");
		BeanFactory fact = new XmlBeanFactory(res);*/
/*		IGreet obj1=(IGreet) fact.getBean("gt1");
		System.out.println(obj1.greetMe());
		IGreet obj2=(IGreet) fact.getBean("gt2");
		System.out.println(obj2.greetMe());*/
		ApplicationContext ctx = new ClassPathXmlApplicationContext("cg.xml");
		IGreet obj1=(IGreet) ctx.getBean("gt1");
		System.out.println(obj1.greetMe());
		IGreet obj2=(IGreet) ctx.getBean("gt2");
		System.out.println(obj2.greetMe());
		IGreet obj3=(IGreet) ctx.getBean("gt2");
		System.out.println(obj3.greetMe());
		System.out.println(obj1);
		System.out.println(obj2);
		System.out.println(obj3);

	}

}
