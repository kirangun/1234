package com.cg.demo.bean;

public class BirthdayWishImpl implements IGreet {
	
	String name;
	int year;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("in set name");
		this.name = name;
	}
	@Override
	public String greetMe() {
		return "Happy Birth Day"+name+"in"+year;
	}

	

	public BirthdayWishImpl(String name, int year) {
		super();
		this.name = name;
		this.year = year;
		System.out.println("in bday wish param constructor");
	}

	
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		System.out.println("in set year");
		this.year = year;
	}

	public void setUp() {
		System.out.println("In set Up of Birthday Wish");
	}

	public BirthdayWishImpl() {
		System.out.println("IN default constructor");
	}
	public void tearDown() {
		System.out.println("in birthday teardown");
	}
	
}
