package com.cg.demo.bean;

import java.time.LocalDate;
import java.util.ArrayList;

public class Employee {
	private int empId;
	private String empName;
	private float empSal;
	private Addresss empAdd;   //Has A relationship
	private ArrayList<String> depts; //Employee working in multiple dept
	private LocalDate empDOJ;

	public LocalDate getEmpDOJ() {
		return empDOJ;
	}

	public void setEmpDOJ(LocalDate empDOJ) {
		this.empDOJ = empDOJ;
	}

	public ArrayList<String> getDepts() {
		return depts;
	}

	public void setDepts(ArrayList<String> depts) {
		this.depts = depts;
	}

	public Addresss getEmpAdd() {
		return empAdd;
	}

	public void setEmpAdd(Addresss empAdd) {
		this.empAdd = empAdd;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empAdd=" + empAdd
				+ ", depts=" + depts + ", empDOJ=" + empDOJ + "]";
	}

	

	
	
}
