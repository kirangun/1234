package com.cg.demo.dao;

import java.util.ArrayList;

import com.cg.demo.bin.Author;

public interface IAuthorDao 
{
	public Author addAuthor(Author e);
	public Author daleteAuthorById(int authorId);
	public ArrayList<Author> fetctAllAuthor();
	public Author updateAuthor(int authorId, String no);
	
}

