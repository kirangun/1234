
package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.demo.dto.Login;

@Controller
@RequestMapping("/helloctrl")
public class HelloController 
{

	
	@RequestMapping(value="/ShowLoginPage")
	public String dispHomePage(Model model)
	{
		Login lg = new Login();
		String today = "Today is:  " + LocalDate.now();
		model.addAttribute("msgObj", today);
		model.addAttribute("login", lg);
		return "Login";
		
	}
	
}