package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.Login;

import com.cg.demo.dto.Trainee;

@Repository
@Transactional
public class TraineeDao implements ITraineeDao
{

	@PersistenceContext
	EntityManager em=null;
	public EntityManager getEm() 
	{
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Override
	public Trainee addTraineeDetails(Trainee tr)
	{
		em.persist(tr);
		Trainee obj=em.find(Trainee.class,tr.getTraineeId());
		return obj;
	}

	public void deleteTraineeDetails(int unm)
	{
		Trainee reg=em.find(Trainee.class,unm);
		em.remove(reg);
		System.out.println("ent removed...");
	}
	public void ModifyTraineeDetails(int unm)
	{
		Trainee reg=em.find(Trainee.class,unm);
		reg.setTraineeDomain("dotnet");
		em.merge(reg);
		System.out.println("domain is updated for:"+reg.getTraineeId());
	}

	@Override
	public ArrayList<Trainee> fetchAllUsers(int id) {

		
			String selQ="select reg from Trainee reg where traineeId='"+id+"'";
			TypedQuery<Trainee> tq=em.createQuery(selQ,Trainee.class);
			ArrayList<Trainee> uList=(ArrayList)tq.getResultList();
			return uList;
		
	}
	@Override
	public ArrayList<Trainee> fetchAllUsers() {

		
			String selQ="select reg from Trainee reg";
			TypedQuery<Trainee> tq=em.createQuery(selQ,Trainee.class);
			ArrayList<Trainee> uList=(ArrayList)tq.getResultList();
			return uList;
		
	}
}
