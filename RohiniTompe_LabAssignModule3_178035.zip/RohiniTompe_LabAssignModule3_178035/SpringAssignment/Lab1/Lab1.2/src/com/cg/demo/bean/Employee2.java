package com.cg.demo.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("emp2")
public class Employee2 
{
	@Value("17777")
	private int eId;
	@Value("vaishali")
	private String ename;
	@Value("50000")
	private double salary;
	@Autowired
	private SBU buisnessUnit;
	@Value("25")
	private int age;
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}


	public SBU getBuisnessUnit() {
		return buisnessUnit;
	}
	public void setBuisnessUnit(SBU buisnessUnit) {
		this.buisnessUnit = buisnessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public Employee2(int eId, String ename, double salary, SBU buisnessUnit, int age) {
		super();
		this.eId = eId;
		this.ename = ename;
		this.salary = salary;
		this.buisnessUnit = buisnessUnit;
		this.age = age;
	}
	public Employee2() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", ename=" + ename + ", salary=" + salary + ",  sbu details=" + buisnessUnit
				+ ", age=" + age + "]";
	}

	
	
	
	
}
