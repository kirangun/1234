package com.cg.demo.bean;

import org.springframework.stereotype.Component;

@Component("emp1")
public class Employee 
{
	private int eId;
	private String ename;
	private double salary;

	
	public int getId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Employee(int eId, String ename, double salary) {
		super();
		this.eId = eId;
		this.ename = ename;
		this.salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", ename=" + ename + ", salary=" + salary + "]";
	}


	
	
	
}
