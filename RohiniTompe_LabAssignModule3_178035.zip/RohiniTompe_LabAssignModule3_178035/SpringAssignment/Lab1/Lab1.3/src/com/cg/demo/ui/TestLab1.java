package com.cg.demo.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demo.bean.Employee;
import com.cg.demo.bean.Employee2;

import com.cg.demo.bean.SBU;



@ComponentScan(basePackages="com.cg.demo.bean")
public class TestLab1 {

	public static void main(String[] args) {
		
//System.out.println("xml configuration");
//ApplicationContext ctx1=new ClassPathXmlApplicationContext("cg.xml");
// SBU obj1=(SBU) ctx1.getBean("emp1");
//System.out.println(obj1);
//    System.out.println("xml+spring configuration");
//	ApplicationContext ctx1=new ClassPathXmlApplicationContext("cg2.xml");
//    Employee2 obj2=(Employee2) ctx1.getBean("emp2");
//    System.out.println(obj2);
//		
	ApplicationContext ctx=SpringApplication.run(TestLab1.class, args);
	System.out.println("spring annotation");
	SBU obj3=(SBU) ctx.getBean("bu");
	System.out.println(obj3);
	System.out.println("Employee Details:");
	System.out.println("-------------------");
	System.out.println(obj3.getEmpList());
	
	
}

}
