package com.cg.demo.bean;

import java.beans.PropertyEditor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.config.CustomEditorConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;


@Configuration
public class SpringConfig
{
	@Bean
	public ArrayList<Employee> getEmp()
	{
		ArrayList<Employee> depList=new ArrayList<Employee>();
		Employee e=new Employee();
		e.seteId(111);
		e.setEname("aakash");
		e.setSalary(25000);
		Employee e1=new Employee();
		e1.seteId(111);
		e1.setEname("aakash");
		e1.setSalary(25000);
		depList.add(e);
		depList.add(e1);
		return depList;
	}
	
	

}
