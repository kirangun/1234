package com.cg.demo.bean;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component("bu")
public class SBU 
{
	@Value("255")
	private int sbuId;
	@Value("rohini")
	private String sbuName;
	@Value("amol")
	private String sbuHead;
	@Resource(name="getEmp")
	private List<Employee> empList;
	
	
	public SBU(int sbuId, String sbuName, String sbuHead) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getEmpList() {
		return empList;
	}
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	@Override
	public String toString() {
		return "SBU details:\n---------------\nsbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead ;
	}

	
	
	
}
