package com.cg.demo.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("e3")
public class Employee3 
{ 
	@Value("178039")
	private int eId;
	@Value("rohit tompe")
	private String ename;
	@Value("250000")
	private double salary;
	@Value("PSE-BU")
	private String buisnessUnit;
	@Value("25")
	private int age;
	
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getBuisnessUnit() {
		return buisnessUnit;
	}
	public void setBuisnessUnit(String buisnessUnit) {
		this.buisnessUnit = buisnessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee3(int eId, String ename, double salary, String buisnessUnit, int age) {
		super();
		this.eId = eId;
		this.ename = ename;
		this.salary = salary;
		this.buisnessUnit = buisnessUnit;
		this.age = age;
	}
	public Employee3() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", ename=" + ename + ", salary=" + salary + ", buisnessUnit=" + buisnessUnit
				+ ", age=" + age + "]";
	}
	
	
	
}
