package com.cg.demo.bean;

public class Employee 
{
	private int eId;
	private String ename;
	private double salary;
	private String buisnessUnit;
	private int age;
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getBuisnessUnit() {
		return buisnessUnit;
	}
	public void setBuisnessUnit(String buisnessUnit) {
		this.buisnessUnit = buisnessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(int eId, String ename, double salary, String buisnessUnit, int age) {
		super();
		this.eId = eId;
		this.ename = ename;
		this.salary = salary;
		this.buisnessUnit = buisnessUnit;
		this.age = age;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", ename=" + ename + ", salary=" + salary + ", buisnessUnit=" + buisnessUnit
				+ ", age=" + age + "]";
	}
	
	
	
}
