package com.cg.author.service;

public interface IAuthorService {

}
