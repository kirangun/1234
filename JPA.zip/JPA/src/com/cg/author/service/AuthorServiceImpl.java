package com.cg.author.service;

public class AuthorServiceImpl implements IAuthorService {

}
