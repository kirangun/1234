package com.cg.author.dao;

public interface IAuthorDao {

}
