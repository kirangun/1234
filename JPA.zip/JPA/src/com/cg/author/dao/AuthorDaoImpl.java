package com.cg.author.dao;

public class AuthorDaoImpl implements IAuthorDao {

}
