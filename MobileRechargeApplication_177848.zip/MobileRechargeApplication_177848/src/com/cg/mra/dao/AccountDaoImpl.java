package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mra.beans.Account;
import com.cg.mra.dbutil.DBUtil;
import com.cg.mra.exception.MobileException;

public class AccountDaoImpl implements AccountDao {
	Connection conn = null;

	@Override
	public Account getAccountDetails(String accId) throws MobileException {
		Account acc = new Account();
		String sql="Select * from account1 where account_id=?";
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(sql);
		
		pst.setString(1, accId);
		ResultSet rst = pst.executeQuery();
		while(rst.next())
		{
				acc.setAccountId(rst.getString(1));
				acc.setAccountType(rst.getString(2));
				acc.setCustomerName(rst.getString(3));
				acc.setAccountBalance(rst.getDouble(4));
		
		}	
		} catch (SQLException e) {
			throw new MobileException("Error Fetching Details");
		}
		return acc;
	}

	@Override
	public int rechargeAccount(String accId, Double rechargeAmount) throws MobileException
	{
		Account acc = new Account();
		conn = DBUtil.getConnection();
		String sql="Select * from account1 where account_id=?";
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(sql);
		
		pst.setString(1, accId);
		ResultSet rst = pst.executeQuery();
		while(rst.next())
		{
				acc.setAccountId(rst.getString(1));
				acc.setAccountType(rst.getString(2));
				acc.setCustomerName(rst.getString(3));
				acc.setAccountBalance(rst.getDouble(4));
		
		}	
		String sql1= "update account1 set acc_balance=acc_balance+? where account_id=?  ";
		pst = conn.prepareStatement(sql1);
		pst.setDouble(1, rechargeAmount);
		pst.setString(2, accId);
		int  r =pst.executeUpdate();
		if(r==1)
			return 1;
		
		} catch (SQLException e) {
			throw new MobileException("Recharge Failed");
		}
		
		
		return 0;
	}

}
