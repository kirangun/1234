package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;

public interface AccountDao {

	Account getAccountDetails(String accId) throws MobileException;

	int rechargeAccount(String accId, Double rechargeAmount) throws MobileException;

}
