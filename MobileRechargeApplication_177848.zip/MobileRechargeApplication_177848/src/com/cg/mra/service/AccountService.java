package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;

public interface AccountService {

	Account getAccountDetails(String accId) throws MobileException;

	int rechargeAccount(String accId, Double rechargeAmount) throws MobileException;

	boolean validateAccountId(String accId) throws MobileException;


}
