package com.capgemini.doctors.exception;

public class DoctorException extends Exception {

	// default serialversionUID to avoid warnings
	private static final long serialVersionUID = 1L;

	public DoctorException(String string) {
		System.err.println(string);
	}

}
