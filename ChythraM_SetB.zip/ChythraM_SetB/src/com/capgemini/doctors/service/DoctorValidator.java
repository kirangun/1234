package com.capgemini.doctors.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DoctorValidator {

	public boolean validatePhoneNumber(String phoneNumber) {
		if (phoneNumber == null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("[789][0-9]{9}$");
		Matcher mat = pat.matcher(phoneNumber);
		if (mat.matches())
			return true;
		else
			return false;
	}

	public boolean validateEmail(String email) {
		Pattern p = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+[A-Za-z]{2,6}$");
		Matcher mat = p.matcher(email);
		if (mat.matches())
			return true;
		else
			return false;
	}

	public boolean validatePatientName(String patientName) {
		Pattern pat = Pattern.compile("[A-Za-z]{4,15}");
		Matcher mat = pat.matcher(patientName);
		if (mat.matches())
			return true;
		else
			return false;
	}

	public boolean validateGender(String gender) {
		if (gender.equalsIgnoreCase("male")) {
			return true;
		} else if (gender.equalsIgnoreCase("female")) {
			return true;
		} else if (gender.equalsIgnoreCase("other")) {
			return true;
		}
		return false;
	}

	public boolean validateProblemName(String problemName) {
		if (problemName.equalsIgnoreCase("Heart")) {
			return true;
		} else if (problemName.equalsIgnoreCase("Gynecology")) {
			return true;
		} else if (problemName.equalsIgnoreCase("Diabetes")) {
			return true;
		} else if (problemName.equalsIgnoreCase("ENT")) {
			return true;
		} else if (problemName.equalsIgnoreCase("Bone")) {
			return true;
		} else if (problemName.equalsIgnoreCase("Dermatology")) {
			return true;
		}
		return false;
	}
}
