package com.capgemini.doctors.service;

import java.util.Random;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao dao = new DoctorAppointmentDao();

	// pass the doctorAppointment to the dao layer
	@Override
	public int addDoctorAppoinmentDetails(DoctorAppointment doctorAppointment) {
		int appoinmentId = generateAppointmentId();
		doctorAppointment.setAppoinmentId(appoinmentId);
		int appointmentId = dao.addDoctorAppointmentDetails(doctorAppointment);
		return appointmentId;
	}

	// generates the random number to set the appointment id
	private int generateAppointmentId() {
		Random rand = new Random();
		int appointmentId = rand.nextInt(10000);
		return appointmentId;
	}

	// returns the doctorAppointment to the main class
	@Override
	public DoctorAppointment getDoctorAppointment(int appointmentId) {
		DoctorAppointment doctorAppointment = dao.getAppoinmentDetails(appointmentId);
		return doctorAppointment;
	}

	// update the doctor name according to the problem name
	@Override
	public String updateDoctor(String problemName) {
		String doctorName = null;
		if (problemName.equalsIgnoreCase("Heart")) {
			doctorName = "Dr.Brijesh Kumar";
		} else if (problemName.equalsIgnoreCase("Gynecology")) {
			doctorName = "Dr.Sharada Singh";
		} else if (problemName.equalsIgnoreCase("Diabetes")) {
			doctorName = "Dr.Heena Khan";
		} else if (problemName.equalsIgnoreCase("ENT")) {
			doctorName = "Dr.Paras mal";
		} else if (problemName.equalsIgnoreCase("Bone")) {
			doctorName = "Dr.Renuka Kher";
		} else if (problemName.equalsIgnoreCase("Dermatology")) {
			doctorName = "Dr.Kanika Kapoor";
		}
		return doctorName;
	}

}
