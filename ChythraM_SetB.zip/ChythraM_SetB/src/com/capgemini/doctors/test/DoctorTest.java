package com.capgemini.doctors.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.capgemini.doctors.service.DoctorValidator;

class DoctorTest {

	@Test
	public void testPhoneNumber() {
		DoctorValidator validator = new DoctorValidator();
		String phoneNumber = "12323423";
		boolean actual = validator.validatePhoneNumber(phoneNumber);
		boolean expected=false;
		assertEquals(expected, actual);
	}
	@Test
	public void testEmail() {
		DoctorValidator validator = new DoctorValidator();
		String email = "asdf@gmail";
		boolean actual = validator.validatePhoneNumber(email);
		boolean expected=false;
		assertEquals(expected, actual);
	}
	@Test
	public void testProblemName() {
		DoctorValidator validator = new DoctorValidator();
		String problemname = "ent";
		boolean actual = validator.validatePhoneNumber(problemname);
		boolean expected=false;
		assertEquals(expected, actual);
	}
}
