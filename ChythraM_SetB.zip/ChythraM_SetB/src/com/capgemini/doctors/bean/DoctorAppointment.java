package com.capgemini.doctors.bean;

import java.time.LocalDate;

public class DoctorAppointment {

	private int appoinmentId;
	private String patientName;
	private String phoneNumber;
	private String email;
	private LocalDate appointmentDate;
	private int age;
	private String problemName;
	private String doctorName;
	private String applicationStatus;
	private String gender;

	public int getAppoinmentId() {
		return appoinmentId;
	}

	public void setAppoinmentId(int appoinmentId) {
		this.appoinmentId = appoinmentId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getProblemName() {
		return problemName;
	}

	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	@Override
	public String toString() {
		return "DoctorAppointment [appoinmentId=" + appoinmentId + ", patientName=" + patientName + ", phoneNumber="
				+ phoneNumber + ", email=" + email + ", appointmentDate=" + appointmentDate + ", age=" + age
				+ ", problemName=" + problemName + ", doctorName=" + doctorName + ", applicationStatus="
				+ applicationStatus + "]";
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
}
