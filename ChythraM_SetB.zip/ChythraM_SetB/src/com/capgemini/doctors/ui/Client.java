package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.DoctorValidator;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {

	public static void main(String[] args) {

		String patientName;
		String phoneNumber;
		String email;
		int age;
		String gender;
		String problemName;
		Scanner scan = new Scanner(System.in);

		int option = 0;
		do {
			System.out.println("1. Book Doctor Appointment");
			System.out.println("2. View Doctor Appointment");
			System.out.println("3. Exit");
			option = scan.nextInt();
			scan.nextLine();
			DoctorValidator validator = new DoctorValidator();
			IDoctorAppointmentService service = new DoctorAppointmentService();
			switch (option) {
			case 1:
				DoctorAppointment doctorAppointment = new DoctorAppointment();
				System.out.println("Enter Name of the patient :");
				patientName = scan.nextLine();
				if (validator.validatePatientName(patientName) == false)
					try {
						throw new DoctorException("Enter the patient name");
					} catch (DoctorException e) {
						break;
					}
				System.out.println("Enter PhoneNumber :");
				phoneNumber = scan.nextLine();
				if (validator.validatePhoneNumber(phoneNumber) == false)
					try {
						throw new DoctorException("Enter the Valid phone number");
					} catch (DoctorException e) {
						break;
					}
				System.out.println("Enter Email :");
				email = scan.nextLine();
				if (validator.validateEmail(email) == false)
					try {
						throw new DoctorException("Enter the Valid email1");
					} catch (DoctorException e) {
						break;
					}
				System.out.println("Enter Age");
				age = scan.nextInt();
				scan.nextLine();
				System.out.println("Enter Gender");
				gender = scan.nextLine();
				if (validator.validateGender(gender) == false)
					try {
						throw new DoctorException("Enter the Valid Gender");
					} catch (DoctorException e) {
						break;
					}
				System.out.println("Enter Problem Name");
				problemName = scan.nextLine();
				if (validator.validateProblemName(problemName) == false) {
					doctorAppointment.setApplicationStatus("DISAPPROVED");
				} else {
					doctorAppointment.setApplicationStatus("APPROVED");
				}
				// set values in the doctor appointment object
				doctorAppointment.setPatientName(patientName);
				doctorAppointment.setAge(age);
				doctorAppointment.setEmail(email);
				doctorAppointment.setGender(gender);
				doctorAppointment.setProblemName(problemName);
				doctorAppointment.setPhoneNumber(phoneNumber);
				doctorAppointment.setDoctorName(service.updateDoctor(problemName));
				int appointmentId = service.addDoctorAppoinmentDetails(doctorAppointment);
				System.out.println("Your Doctor Appoinment has been successfully registered, your application ID is :"
						+ appointmentId);
				break;
			case 2:
				System.out.println("Enter the application id :");
				appointmentId = scan.nextInt();
				scan.hasNextLine();
				doctorAppointment = service.getDoctorAppointment(appointmentId);
				if (doctorAppointment == null) {
					System.err.println("Your application id is incorrect");
				} else {
					System.out.println("Patient Name : " + doctorAppointment.getPatientName());
					System.out.println("Appointment Status " + doctorAppointment.getApplicationStatus());
					System.out.println("Doctor Name : " + doctorAppointment.getDoctorName());
					System.out.println("Appointment Date and Time, along with doctor's phone number will be shared shortly with you");
				}
				break;
			case 3:
				System.exit(0);
			}
		} while (option < 3);
		scan.close();
	}

}
