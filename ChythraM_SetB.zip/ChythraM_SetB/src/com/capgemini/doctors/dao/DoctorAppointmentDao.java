package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	static Map<Integer, DoctorAppointment> appointments = new HashMap<>();

	// method adds the appointments to the HashMap
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		appointments.put(doctorAppointment.getAppoinmentId(), doctorAppointment);
		return doctorAppointment.getAppoinmentId();
	}

	// returns the doctor appointment according to the appointment id
	@Override
	public DoctorAppointment getAppoinmentDetails(int appointmentId) {
		DoctorAppointment doctorAppointment = appointments.get(appointmentId);
		return doctorAppointment;
	}

}
