package com.cg.demo.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;

import com.cg.demo.bean.Employee;

public class Test {
	public static void main(String[] args) {
		Employee e1=null;
		e1=new Employee();
		Employee e2 = new Employee(22, "Samir", 6000.0F, LocalDate.now());
		System.out.println("annual salary"+e2.getEmpSal()*12);
		try {
			FileOutputStream fos = new FileOutputStream("EmpInfo.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeInt(e2.getEmpId());
			oos.writeUTF(e2.getEmpName());
			oos.writeFloat(e2.getEmpSal());
			oos.writeObject(e2.getEmpDOJ());
			System.out.println("e2 instance data is written in the file");
		} catch (IOException e) {
			e.printStackTrace();
		
		}
		
}
}
