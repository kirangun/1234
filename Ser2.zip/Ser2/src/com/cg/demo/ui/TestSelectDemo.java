package com.cg.demo.ui;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;


public class TestSelectDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g", "lab2etrg35", "lab2eoracle");
//			String query = "Select emp_name,emp_id,emp_sal,emp_doj from employee";
//			String query = "Select emp_name,emp_id,emp_sal,emp_doj from employee where emp_sal>? and emp_sal<?"+"and emp_id>?";
//			Statement st = con.createStatement();
			System.out.println("Enter EmpId");
			int eid=sc.nextInt();
			System.out.println("Enter EmpName");
			String ename = sc.next();
			System.out.println("Enter Salary");
			float esal = sc.nextFloat();
			System.out.println("Enter Day of join");
			int dd = sc.nextInt();
			System.out.println("Enter Month of join");
			int mm = sc.nextInt();
			System.out.println("Enter year of join");
			int yy=sc.nextInt();
			LocalDate doj = LocalDate.of(yy, mm, dd);
			Date mySqlDOJ =convertLocalToSQLDate(doj);
			String insertq = "insert into employee(emp_id,emp_name,emp_sal,emp_doj)values(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(insertq);
			ps.setInt(1, eid);
			ps.setString(2, ename);
			ps.setFloat(3, esal);
			ps.setDate(4, mySqlDOJ);
			int dataInserted =ps.executeUpdate();
			System.out.println("Date inserted in table"+dataInserted);
			
			/*ResultSet rs =ps.executeQuery();
			System.out.println("Empid\tempName\tempSal\tempDoj");
			while(rs.next())
			{
				System.out.println(rs.getInt(2)+"\t"+rs.getString(1)+"\t"+rs.getFloat(3)+"\t"+rs.getDate(4) );
			}*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		private static java.sql.Date convertLocalToSQLDate(LocalDate doj)
		{
			Date mySqlDoj=Date.valueOf(doj);
			return mySqlDoj;
		}
		
	}
	
	

