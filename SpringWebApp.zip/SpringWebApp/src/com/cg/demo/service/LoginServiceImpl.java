package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.ILoginDao;
import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;
@Service
public class LoginServiceImpl implements ILoginService {
	@Autowired
	ILoginDao loginDao;
	public ILoginDao getLoginDao() {
		return loginDao;
	}


	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}


	@Override
	public Login validateUser(Login user) {
		return loginDao.validateUser(user);
	}


	@Override
	public Register addUserDetails(Register reg) {
		return loginDao.addUserDetails(reg);
	}


	@Override
	public Login addUser(Login log) {
		return loginDao.addUser(log);
	}


	@Override
	public ArrayList<Register> fetchAllUser() {
		return loginDao.fetchAllUser();
	}


	@Override
	public void delUser(String unm) {
		loginDao.delUser(unm);
		
	}

}
