package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;
import com.cg.demo.service.ILoginService;

@Controller
public class LoginController {
	@Autowired
	ILoginService logServ = null;

	public ILoginService getLogServ() {
		return logServ;
	}

	public void setLogServ(ILoginService logServ) {
		this.logServ = logServ;
	}

	@RequestMapping(value = "/LoginPage", method = RequestMethod.GET)
	public String dispLoginPage(Model model) {
		Login lg = new Login();
		String msg = "Today is " + LocalDate.now();
		model.addAttribute("msgObj", msg);
		model.addAttribute("loginObj", lg);
		return "Login";
	}

	@RequestMapping(value = "/ValidateUser", method = RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginObj") @Valid Login lgg, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "Login";
		} else {
			Login user = logServ.validateUser(lgg);
			if (user != null) {
				if (user.getPassword().equalsIgnoreCase(lgg.getPassword())) {
					String msg = "Welcome U r valid user" + user.getPassword();
					model.addAttribute("MsgObj", msg);
					return "Success";
				} else {
					String msg = "Sorry Invalid Password";
					model.addAttribute("MsgObj", msg);
					return "Login";
				}
			} else {
				Register reg = new Register();
				model.addAttribute("userObj", reg);
				ArrayList<String> cityList = new ArrayList<>();
				cityList.add("Pune");
				cityList.add("Noida");
				cityList.add("Nagpur");
				cityList.add("Mumbai");
				model.addAttribute("cList", cityList);
				ArrayList<String> skills = new ArrayList<>();
				skills.add("Java");
				skills.add("Oracle");
				skills.add("BI");
				skills.add("Html");
				model.addAttribute("skillList", skills);
				return "Register";
			}
		}
	}
		@RequestMapping(value="/InsertUserDetails")
		public String addUser(@ModelAttribute("userObj")
			Register reg,Model model,BindingResult result){
			String sMsg = "Data is inserted successfully";
			String eMsg = "Error in insertion";
			Register rg=logServ.addUserDetails(reg);
				Login lg=logServ.addUser(new Login(reg.getUname(),reg.getPwd()));
				model.addAttribute("UserDataObj", reg);
				if(rg!=null && lg!=null) {
					model.addAttribute("msgObj", sMsg);
				}
				else
				{
					model.addAttribute("msgObj", eMsg);
				}
				ArrayList<Register> uList = logServ.fetchAllUser();
				model.addAttribute("UserListObj",uList);
				return "ListAllUser";
			}
		@RequestMapping(value="/DeleteUser")
		public String delUser(Model model ,@RequestParam("unm") String name) {
			logServ.delUser(name);
			/*ArrayList<Register> uList= logServ.fetchAllUser();
			model.addAttribute("UserListObj",uList);
			return "ListAllUser";*/
			return "redirect:ShowAllUserDetails.qwe";
			
		}
		@RequestMapping(value="/ShowAllUserDetails")
		public String dispAllUserDetails(Model model) {
			ArrayList<Register> uList= logServ.fetchAllUser();
			model.addAttribute("UserListObj",uList);
			return "ListAllUser";
		}
}

