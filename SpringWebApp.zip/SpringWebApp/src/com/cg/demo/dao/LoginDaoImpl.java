package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Register;
@Repository
@Transactional
public class LoginDaoImpl implements ILoginDao {
	@PersistenceContext  																				// It will inject entitymgr object in present class
	EntityManager entityMgr = null;
	
	public EntityManager getEntityMgr() {
		return entityMgr;
	}

	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}

	@Override
	public Login validateUser(Login user) {
		Login usr = entityMgr.find(Login.class, user.getUsername());
		return usr;
		
}

	@Override
	public Register addUserDetails(Register reg) {
		entityMgr.persist(reg);
		Register obj = entityMgr.find(Register.class, reg.getUname());
		return obj;
	}

	@Override
	public Login addUser(Login log) {
		entityMgr.persist(log);
		Login obj = entityMgr.find(Login.class, log.getUsername());
		return obj;
	}

	@Override
	public ArrayList<Register> fetchAllUser() {
		String selQ = "select reg from Register reg";
		TypedQuery<Register> tq=entityMgr.createQuery(selQ,Register.class);
		ArrayList<Register>uList = (ArrayList<Register>) tq.getResultList();
		return uList;
	}

	@Override
	public void delUser(String unm) {
		
		Register reg = entityMgr.find(Register.class, unm);
		Login log = entityMgr.find(Login.class, unm);
		entityMgr.remove(reg);
		entityMgr.remove(log);
		System.out.println("Removedd........");
		
	}
}
