package com.cg.demo.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.demo.dto.Add;
import com.cg.demo.dto.Login;
import com.cg.demo.service.ILoginService;

@Controller
public class LoginController {
	@Autowired
	ILoginService logServ = null;

	public ILoginService getLogServ() {
		return logServ;
	}

	public void setLogServ(ILoginService logServ) {
		this.logServ = logServ;
	}

	@RequestMapping(value = "/LoginPage", method = RequestMethod.GET)
	public String dispLoginPage(Model model) {
		Login login = new Login();
		model.addAttribute("loginObj", login);
		return "Login";
	}
	
	@RequestMapping(value = "/ValidateUser", method = RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginObj") Login lgn, Model model) {
		Login user = logServ.validateUser(lgn);
		if (user != null) {
			if (user.getPassword().equals(lgn.getPassword()))
			{
			
				return "TMS";
			}
			else
			{
				String msg = "Sorry Invalid Password";
				model.addAttribute("MsgObj", msg);
				return "Login";
			}
		}
		
		return "Login";
				
	}

	@RequestMapping(value = "/addTrainee")
	public String addTrainee(Model model) {
		Add ad = new Add();
		model.addAttribute("traineeObj", ad);
		ArrayList<String> dList = new ArrayList<>();
		dList.add("JEE");
		dList.add("Oracle");
		dList.add("SalesForce");
		model.addAttribute("domainList",dList);
		return "Add";
	}
	@RequestMapping(value="/add")
	public String addTraine(@ModelAttribute("traineeObj") Add ad,Model model) {
		Add add=logServ.addTraine(ad);
		model.addAttribute("traineeObj",add);
		return "Success";
		
	}
	@RequestMapping(value= "/deleteTrainee")
	public String deleteTrainee(Model model) {
		Add ad = new Add();
		model.addAttribute("delete",ad);  //
	 return "DeleteTrainee";
	}
	@RequestMapping(value="/showAll")
	public String retrieveAllTrainee(Model model) {
		ArrayList<Add> list = logServ.fetchAllTrainee();
		model.addAttribute("UserListObj",list);
		return "retrieveAll";
	}
	@RequestMapping(value="/retriveOne")
	public String retrieveOne(Model model) {
		Add ad = new Add();
		model.addAttribute("retrieve",ad);
		return "retrieveTrainee";	
	}
	@RequestMapping(value="/modifyTrainee")
	public String modifyTrainee(Model model) {
		Add ad = new Add();
		model.addAttribute("modify",ad);
		return "modifyTrainee";
	}
	@RequestMapping(value="/retrieve")
	public String retrieveOne(@ModelAttribute("modify") Add ad,Model model) {
		 ad =logServ.retrieveOne(ad);
		model.addAttribute("retrieve",ad);
		return "retrieveTrainee";	
	}
	@RequestMapping(value="/get")
	public String getOne(@ModelAttribute("modify") Add ad,Model model) {
		 ad =logServ.retrieveOne(ad);
		model.addAttribute("retrieve",ad);
		Add modify=new Add();
		model.addAttribute("modify",modify);
		return "modifyTrainee";	
	}
	@RequestMapping(value="/delete")
	public String deleteTrainee(@ModelAttribute("delete") Add ad ,Model model) {
		ad=logServ.deleteTrainee(ad);
		model.addAttribute("delete",ad);
		return "DeleteTrainee";
	}
	@RequestMapping(value="/modify")
	public String modifyTrainee(@ModelAttribute Add modify ,Model model) {
		modify=logServ.modifyTrainee(modify);
		model.addAttribute("modify",modify);
		return "redirect:showAll.obj";
	}
}
