package com.cg.demo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trainee")
public class Add {
	@Id
	@Column(name="trainee_id",length=10)
	private int traineeId;
	@Column(name="trainee_name",length=10)
	private String traineeName;
	@Column(name="trainee_domain",length=10)
	private String traineeDomain;
	@Column(name="trainee_location",length=10)
	private String location;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Add(int traineeId, String traineeName, String traineeDomain, String location) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.location = location;
	}
	public Add() {
		super();
	}
	@Override
	public String toString() {
		return "Add [traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeDomain=" + traineeDomain
				+ ", location=" + location + "]";
	}
	
}
