package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.ILoginDao;
import com.cg.demo.dto.Add;
import com.cg.demo.dto.Login;
@Service
public class LoginServiceImpl implements ILoginService {
	@Autowired
	ILoginDao loginDao;
	public ILoginDao getLoginDao() {
		return loginDao;
	}


	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}


	@Override
	public Login validateUser(Login user) {
		return loginDao.validateUser(user);
	}


	@Override
	public Add addTraine(Add ad) {
		return loginDao.addTraine(ad);
	}


	@Override
	public ArrayList<Add> fetchAllTrainee() {
		return loginDao.fetchAllTrainee();
	}

	@Override
	public Add retrieveOne(Add ad) {
		return loginDao.retrieveOne(ad);
	}


	@Override
	public Add deleteTrainee(Add ad) {
	
		return loginDao.deleteTrainee(ad);
	}


	@Override
	public Add modifyTrainee(Add ad) {
		return loginDao.modifyTrainee(ad);
	}

}
