package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.dto.Add;
import com.cg.demo.dto.Login;

public interface ILoginService {
	public Login validateUser(Login user);

	public Add addTraine(Add ad);

	public ArrayList<Add> fetchAllTrainee();

	public Add retrieveOne(Add ad);

	public Add deleteTrainee(Add ad);

	public Add modifyTrainee(Add ad);
}
