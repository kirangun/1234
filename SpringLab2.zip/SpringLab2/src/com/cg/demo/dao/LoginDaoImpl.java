package com.cg.demo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.Add;
import com.cg.demo.dto.Login;
@Transactional
@Repository
public class LoginDaoImpl implements ILoginDao {
	@PersistenceContext  																				// It will inject entitymgr object in present class
	EntityManager entityMgr = null;
	
	public EntityManager getEntityMgr() {
		return entityMgr;
	}

	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}

	@Override
	public Login validateUser(Login user) {
		Login usr = entityMgr.find(Login.class, user.getUsername());
		return usr;
		
}

	@Override
	public Add addTraine(Add ad) {
		entityMgr.persist(ad);
		Add add = entityMgr.find(Add.class, ad.getTraineeId());
		return add;
		
	}

	@Override
	public ArrayList<Add> fetchAllTrainee() {
		 ArrayList<Add> list = (ArrayList<Add>) entityMgr.createQuery("select zyz from Add zyz", Add.class).getResultList();
		return list;
	}
	@Override
	public Add retrieveOne(Add ad) {
		return entityMgr.find(Add.class, ad.getTraineeId());
	}

	@Override
	public Add deleteTrainee(Add ad) {
		ad = entityMgr.find(Add.class, ad.getTraineeId());
		entityMgr.remove(ad);
		return ad;
	}

	@Override
	public Add modifyTrainee(Add ad) {
		entityMgr.merge(ad);
		return ad;
	}
}
