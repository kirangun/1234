package com.cg.demo.bean;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
@DiscriminatorValue("MGR")
public class Manager extends Employee {
	private String deptName;

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public Manager(int empId, int empSal, String deptName) {
		super(empId, empSal);
		this.deptName = deptName;
	}

	public Manager(int empId, int empSal) {
		super(empId, empSal);
	}

	@Override
	public String toString() {
		return "Manager [deptName=" + deptName + "]";
	}

	public Manager() {
		super();
	}
	
}
