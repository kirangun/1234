package com.cg.demo.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.demo.bean.Employee;
import com.cg.demo.bean.Manager;
import com.cg.demo.util.JPAUtil;

public class TestInheritanceDemo {
public static void main(String[] args) {
	EntityManager em = JPAUtil.getEntityManager();
	EntityTransaction tran = em.getTransaction();
	
	Employee e1 = new Employee();
	e1.setEmpName("kiran");
	e1.setEmpSal(500);
	
	Employee e2 = new Employee();
	e2.setEmpName("gundeti");
	e2.setEmpSal(600);
	
	
	Manager m3 = new Manager();
	m3.setEmpName("Vaishali");
	m3.setEmpSal(600);
	m3.setDeptName("Java");
	tran.begin();
	em.persist(e1);
	em.persist(e2);
	em.persist(m3);
	tran.commit();
	System.out.println("Data is added ");
}

}
