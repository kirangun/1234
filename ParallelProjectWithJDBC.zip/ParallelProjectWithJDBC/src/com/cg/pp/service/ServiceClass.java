package com.cg.pp.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;
import com.cg.pp.dao.DaoClass;
import com.cg.pp.dao.DaoInterface;
import com.cg.pp.exception.CustomerException;

public class ServiceClass implements ServiceInterface {

	DaoInterface dao = new DaoClass();
	Customer customer;

	@Override
	public int addCustomer(Customer customer) throws SQLException {
		int accno = dao.addCustomer(customer);
		return accno;
	}

	@Override
	public Customer getCustomer(int accno) throws SQLException {
		customer = dao.getCustomer(accno);
		return customer;
	}

	@Override
	public Transaction depositMoney(int accno, double amount) throws CustomerException, SQLException {
		String txn_type = "Deposit";
		customer = dao.getCustomer(accno);
		Transaction txn = generateTxn(accno, amount, txn_type);
		if (customer.getBalance() >= amount) {
			customer.setBalance(customer.getBalance() - amount);
			customer.setAmount(customer.getAmount() + amount);
		} else {
			throw new CustomerException("Amount insufficient in your account");
		}
		dao.updateCustomer(customer);
		int txnId = dao.addTransaction(accno, txn);
		txn.setTxnId(txnId);
		return txn;
	}

	private Transaction generateTxn(int accno, double amount, String txn_type) throws SQLException {
		customer = getCustomer(accno);
		Transaction txn = new Transaction(customer, amount, txn_type);
		return txn;
	}

	@Override
	public boolean verifyPassword(int accno, String password) throws CustomerException, SQLException {
		customer = dao.getCustomer(accno);
		if (customer == null)
			throw new CustomerException("Customer does not exist");
		if (customer.getPassword().equals(password))
			return true;
		else
			return false;
	}

	@Override
	public Transaction withdrawMoney(int accno, double amount) throws CustomerException, SQLException {
		String txn_type = "Withdraw";
		Transaction txn = generateTxn(accno, amount, txn_type);
		customer = dao.getCustomer(accno);
		if (customer.getAmount() >= amount) {
			customer.setBalance(customer.getBalance() + amount);
			customer.setAmount(customer.getAmount() - amount);
		} else {
			throw new CustomerException("Amount insufficient in your Wallet");
		}
		dao.updateCustomer(customer);
		int txnId = dao.addTransaction(accno, txn);
		txn.setTxnId(txnId);
		return txn;
	}

	@Override
	public Transaction fundTransfer(int accno, int trg_accno, double amount) throws CustomerException, SQLException {
		String txn_type = "FundTransfer";
		Transaction txn = generateTxn(accno, amount, txn_type);
		Transaction txn2 = generateTxn(trg_accno, amount, txn_type);
		customer = dao.getCustomer(accno);
		Customer customer2 = dao.getCustomer(trg_accno);
		if (customer2 == null)
			throw new CustomerException("Target Account doesn't exits");
		if (customer.getAmount() >= amount) {
			customer.setAmount(customer.getAmount() - amount);
			customer2.setAmount(customer2.getAmount() + amount);
		} else {
			throw new CustomerException("Amount insufficient in your account");
		}
		dao.updateCustomer(customer);
		dao.updateCustomer(customer2);
		int txnId = dao.addTransaction(accno, txn);
		txn.setTxnId(txnId);
		int txnId1 = dao.addTransaction(trg_accno, txn2);
		txn2.setTxnId(txnId1);
		return txn;
	}

	@Override
	public List<Transaction> printTransactions(int accno) throws SQLException {
		List<Transaction> list = dao.printTransactions(accno);
		return list;
	}

}
