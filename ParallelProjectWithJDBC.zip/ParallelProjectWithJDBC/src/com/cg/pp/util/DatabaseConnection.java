package com.cg.pp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {

	public static Connection getConnection() throws IOException {
		Connection con = null;
		String url = "";
		String user = "";
		String pwd = "";
		InputStream ins = new FileInputStream(
				"D:\\ParallelProjectFinal\\ParallelProjectWithJDBC\\resources\\dbconfig.properties");
		Properties prop = new Properties();
		prop.load(ins);
		url = prop.getProperty("url");
		pwd = prop.getProperty("password");
		user = prop.getProperty("username");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(url, user, pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

}
