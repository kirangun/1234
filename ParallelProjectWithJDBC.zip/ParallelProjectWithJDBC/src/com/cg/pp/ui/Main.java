package com.cg.pp.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;
import com.cg.pp.exception.CustomerException;
import com.cg.pp.service.CustomerValidator;
import com.cg.pp.service.ServiceClass;
import com.cg.pp.service.ServiceInterface;

public class Main {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		String name;
		double balance;
		double amount;
		String password;
		String flatno;
		String street;
		String pincode;
		String city;
		String aadharCard;
		String panCard;
		String phoneNumber;
		int option = 0;
		int accno = 0;
		ServiceInterface si = new ServiceClass();
		CustomerValidator validator = new CustomerValidator();
		Scanner sc = null;
		Customer customer;
		do {
			try {
				System.out.println("1..SignUp");
				System.out.println("2..Login");
				System.out.println("3..Exit");
				System.out.println("Enter your Option");
				sc = new Scanner(System.in);
				option = sc.nextInt();
				sc.nextLine();
				if (option != 1 && option != 2 && option != 3) {
					System.err.println("Select the valid option");
					continue;
				}
				// logic to create account
				if (option == 1) {
					System.out.println("Enter Name");
					name = sc.nextLine();
					if (validator.validateName(name) == false)
						try {
							throw new CustomerException("Enter the valid name");
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							continue;
						}
					System.out.println("Enter Amount");
					balance = sc.nextDouble();
					sc.nextLine();
					if (validator.validateAmount(balance) == false)
						try {
							throw new CustomerException("Amount entered is insufficient");
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							continue;
						}
					System.out.println("Enter password");
					password = sc.nextLine();
					if (validator.validatePassword(password) == false)
						try {
							throw new CustomerException("Password didn't match");
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							continue;
						}
					System.out.println("Enter flatNo");
					flatno = sc.nextLine();
					System.out.println("Enter street");
					street = sc.nextLine();
					System.out.println("Enter city");
					city = sc.nextLine();
					System.out.println("Enter pincode");
					pincode = sc.nextLine();
					if (validator.validatePincode(pincode) == false)
						try {
							throw new CustomerException("Enter the valid Pincode");
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							continue;
						}
					System.out.println("Enter the aadhar card number");
					aadharCard = sc.nextLine();
					if (validator.validateAadharCard(aadharCard) == false)
						try {
							throw new CustomerException("Enter the valid Aadharcard");
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							continue;
						}
					System.out.println("Enter the PanCard number");
					panCard = sc.nextLine();
					if (validator.validatePanCard(panCard) == false)
						try {
							throw new CustomerException("Enter the valid panCard");
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							continue;
						}
					System.out.println("Enter the PhoneNumber");
					phoneNumber = sc.nextLine();
					if (validator.validatePhoneNumber(phoneNumber) == false)
						try {
							throw new CustomerException("Enter the valid phone number");
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							continue;
						}
					customer = new Customer(name, balance, password, flatno, street, city, pincode, aadharCard,panCard,phoneNumber);
					accno = si.addCustomer(customer);
					System.out.println("your account number is :" + accno);
				} else if (option == 2) {
					System.out.println("Enter your account number :");
					accno = sc.nextInt();
					sc.nextLine();
					customer = si.getCustomer(accno);
					System.out.println("Enter the password :");
					password = sc.nextLine();
					try {
						if (si.verifyPassword(accno, password) == false) {
							throw new CustomerException("Entered password is incorrect");
						}
					} catch (CustomerException e) {
						System.err.println(e.getMessage());
						continue;
					}
				} else {
					System.out.println("Thanks for using");
					System.exit(0);
				}
				do {
					System.out.println("1 GetCustomer");
					System.out.println("2 ShowBalance in Wallet");
					System.out.println("3 ShowBalance in Account");
					System.out.println("4 Deposit money into Wallet");
					System.out.println("5 Withdraw money from Wallet");
					System.out.println("6 FundTransfer");
					System.out.println("7 Print Transactions");
					System.out.println("8 Logout");
					System.out.println("Enter your Option");
					option = sc.nextInt();
					sc.nextLine();
					customer = si.getCustomer(accno);
					switch (option) {
					// get customer logic
					case 1:
						customer = si.getCustomer(accno);
						System.out.println("Your Account Name : " + customer.getName());
						System.out.println("Your Address: " + customer.getAddress());
						break;
					// showbalance in wallet
					case 2:
						customer = si.getCustomer(accno);
						System.out.println("Your Wallet Balance : " + customer.getAmount());
						break;
					// showbalance in Account
					case 3:
						customer = si.getCustomer(accno);
						System.out.println("Your Account Balance : " + customer.getBalance());
						break;
					// Deposit money into wallet
					case 4:
						System.out.println("Enter the amount to deposit");
						amount = sc.nextDouble();
						sc.nextLine();
						if (validator.validateAmount(amount) == false)
							try {
								throw new CustomerException("Amount entered is insufficient");
							} catch (CustomerException e) {
								System.err.println(e.getMessage());
								continue;
							}
						Transaction txn = null;
						try {
							txn = si.depositMoney(accno, amount);
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							break;
						}
						System.out.println("Your transaction id : " + txn.getTxnId());
						break;
					// Withdraw money from wallet
					case 5:
						System.out.println("Enter the amount to Withdraw");
						amount = sc.nextDouble();
						sc.nextLine();
						if (validator.validateAmount(amount) == false)
							try {
								throw new CustomerException("Amount entered is insufficient");
							} catch (CustomerException e) {
								System.err.println(e.getMessage());
								continue;
							}
						txn = null;
						try {
							txn = si.withdrawMoney(accno, amount);
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							break;
						}
						System.out.println("Your transaction id : " + txn.getTxnId());
						break;
					// Fund transfer
					case 6:
						System.out.println("Enter the amount to transfer");
						amount = sc.nextDouble();
						if (validator.validateAmount(amount) == false)
							try {
								throw new CustomerException("Amount entered is insufficient");
							} catch (CustomerException e) {
								System.err.println(e.getMessage());
								continue;
							}
						System.out.println("Enter account number to transfer");
						int trg_accno = sc.nextInt();
						sc.nextLine();
						try {
							txn = si.fundTransfer(accno, trg_accno, amount);
						} catch (CustomerException e) {
							System.err.println(e.getMessage());
							break;
						}
						break;
					// Print Transactions
					case 7:
						List<Transaction> list = si.printTransactions(accno);
						if (list == null) {
							System.out.println("No transactions available");
							break;
						}
						for (Iterator<Transaction> iterator = list.iterator(); iterator.hasNext();) {
							Transaction transaction = iterator.next();
							System.out.println(transaction);
						}
						break;
					case 8:
						System.out.println("Thanks for using");
						break;
					}
				} while (true);
			} catch (InputMismatchException e) {
				System.err.println("Enter the valid input format");
				continue;
			} catch(SQLException e) {
				System.err.println("Connection is not established");
				e.printStackTrace();
				continue;
			}
		} while (true);
	}
}