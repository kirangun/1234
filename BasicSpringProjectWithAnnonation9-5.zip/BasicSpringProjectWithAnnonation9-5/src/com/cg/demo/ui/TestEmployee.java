package com.cg.demo.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.cg.demo.bean.Employee;
@ComponentScan(basePackages="com.cg.demo.bean")
public class TestEmployee {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(TestEmployee.class, args);
		Employee e1 = (Employee) ctx.getBean("emp1");
//		Employee e2 = (Employee) ctx.getBean("emp2");
		System.out.println(e1);
//		System.out.println(e2);
	}

}
