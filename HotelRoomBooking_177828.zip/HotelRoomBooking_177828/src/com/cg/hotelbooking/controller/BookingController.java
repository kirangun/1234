package com.cg.hotelbooking.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hotelbooking.beans.Hotel;
import com.cg.hotelbooking.service.IBookingService;


@Controller
public class BookingController {
		@Autowired
		IBookingService service;

		public IBookingService getService() {
			return service;
		}

		public void setService(IBookingService service) {
			this.service = service;
		}

		@RequestMapping("/HotelDetails")
		public String showHome(Model model) {
			Hotel hotel = new Hotel();
			ArrayList<Hotel> hotelList= service.fetchAllDetails(); // All the retrieved hotel details wil be stored into a arraylist
			model.addAttribute("hotel",hotelList); //Adding the HotelList to the model object
			return "HotelDetails";
			
		}
		@RequestMapping("/bookingHotel")
		public String booking(Model model ,@RequestParam("hname") String name ) { // Name from the model object is stored in 
		  																         //name variable
			model.addAttribute("hotel",name);
			return "HotelBookingSuccessPage"; 
			
		}
}
