package com.cg.hotelbooking.service;

import java.util.ArrayList;

import com.cg.hotelbooking.beans.Hotel;

public interface IBookingService {

	ArrayList<Hotel> fetchAllDetails();

}
