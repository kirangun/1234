package com.cg.hotelbooking.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotelbooking.beans.Hotel;
import com.cg.hotelbooking.dao.IBookingDao;
@Service
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IBookingDao dao;
	
	
	@Override
	public ArrayList<Hotel> fetchAllDetails() {
		
		return dao.fetchAllDetails();
	}

}
