package com.cg.hotelbooking.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hotelbooking.beans.Hotel;
@Transactional
@Repository
public class BookingDaoImpl implements IBookingDao {
	
	@PersistenceContext  		
	EntityManager entityMgr = null;    // It will inject entitymgr object in present class

	public EntityManager getEm() {
		return entityMgr;
	}
	public void setEm(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}
	
	//Function to fetch the details of the hotel from the Database.
	@Override
	public ArrayList<Hotel> fetchAllDetails() {
		String selQ = "select xyz from Hotel xyz";
		TypedQuery<Hotel> tq=entityMgr.createQuery(selQ,Hotel.class);
		ArrayList<Hotel>uList = (ArrayList<Hotel>) tq.getResultList();
		return uList;
	}
	
}
