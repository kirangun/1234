package com.cg.hotelbooking.dao;

import java.util.ArrayList;

import com.cg.hotelbooking.beans.Hotel;

public interface IBookingDao {

	ArrayList<Hotel> fetchAllDetails();

}
