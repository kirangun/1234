package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;
import com.capgemini.doctors.service.DoctorAppointmentService;

public class Client {

	public static void main(String[] args) {
		int option;
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		DoctorAppointmentService service = new DoctorAppointmentService();
		do {
		DoctorAppointment doc = new DoctorAppointment();
		System.out.println("Enter your options:->\n1.Book Doctor Appointment \n2.View Doctor Appointment\n3.Exit");
		option = sc.nextInt();
		switch(option) {
		case 1:
			System.out.println("Enter the name of the patient");
			String name = sc.next();
			System.out.println("Enter your phone  number");
			String phone = sc.next();
			System.out.println("Enter email");
			String email = sc.next();
			System.out.println("Enter Age");
			int age = sc.nextInt();
			System.out.println("Enter Gender");
			String gender = sc.next();
			System.out.println("Enter Problem name");
			String problem = sc.next();
			int appointId =((int)(Math.random() * 100000)) % 1000;
			doc.setAge(age);
			doc.setAppointmentDate(LocalDate.now());
			doc.setAppointmentID(appointId);
			doc.setAppointmentStatus("Disapproved");
			doc.setPatientName(name);
			doc.setGender(gender);
			doc.setPhoneNumber(phone);
			doc.setProblemName(problem);
			try {
				service.addDoctorAppointmentDetails(doc);
				System.out.println("Your Doctor Appointment has been successfully registered,your aapointment Id is"+appointId);
			} catch (DoctorAppointmentException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter appointment ID ");
			int id = sc.nextInt();
			try {
				DoctorAppointment doctor = service.getDoctorAppointment(id);
				System.out.println("Patient Name "+doctor.getPatientName());
				System.out.println("Appointment Status"+doctor.getAppointmentStatus());
				System.out.println("Doctor Name"+doctor.getDoctorName());
			} catch (DoctorAppointmentException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
		}while(option !=4);
	}

}
