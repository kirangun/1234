package com.capgemini.doctors.exception;

public class DoctorAppointmentException extends Exception{
public DoctorAppointmentException() {
	
}
public DoctorAppointmentException(String s ) {
	super(s);
}
}
