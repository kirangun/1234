package com.capgemini.doctors.dao;

import java.util.*;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;

public class DoctorAppointmentDao implements IDoctorAppointmentDao{
Map<Integer,DoctorAppointment> appointments = new HashMap();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		if(doctorAppointment == null)
			throw new NullPointerException();
		appointments.put(doctorAppointment.getAppointmentID(), doctorAppointment);
		System.out.println(doctorAppointment);
		return doctorAppointment.getAppointmentID() ;
	}

	@Override
	public DoctorAppointment getDoctorAppointment(int appointmentID) throws DoctorAppointmentException {
		// TODO Auto-generated method stub\
		DoctorAppointment doc = appointments.get(appointmentID);
		return doc;
	}

}
