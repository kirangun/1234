package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Employee;
import com.cg.demo.dao.EmployeeDaoImpl;
import com.cg.demo.dao.IEmployee;

public class EmployeeServiceImpl implements IEmployeeService {
	IEmployee empDao=null;
	public EmployeeServiceImpl() {
		empDao=new EmployeeDaoImpl();
	}
	@Override
	public Employee addEmp(Employee ee) {
		
		return empDao.addEmployee(ee);
	}

	@Override
	public Employee getEmpByID(int empId) {
		return empDao.getEmpByID(empId);
	}
	@Override
	public Employee deleteEmpById(int empId) {
		return empDao.deleteEmpById(empId);
	}
	@Override
	public ArrayList<Employee> fetchAllEmp() {
		
		return empDao.fetchAllEmp();
	}
	@Override
	public Employee updateEmpSal(int empId, float newSal) {
		return empDao.updateEmpSal(empId, newSal);
	}
	}


