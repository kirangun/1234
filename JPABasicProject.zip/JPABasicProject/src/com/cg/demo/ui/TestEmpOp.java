package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.Date;

import com.cg.demo.bean.Employee;
import com.cg.demo.service.EmployeeServiceImpl;
import com.cg.demo.service.IEmployeeService;

public class TestEmpOp {

	public static void main(String[] args) {

		IEmployeeService empserv = new EmployeeServiceImpl();
		
		  Employee e1 = new Employee(); //Inserting data into table
		  e1.setEmpName("Kiran");
		  e1.setEmpSal(789.0f);
		  e1.setEmpDOJ(new Date());
		  empserv.addEmp(e1);
		  /*Employee e2= new Employee();
		  e2.setEmpName("Gundeti");
		  e2.setEmpSal(60000.0f);
		  empserv.addEmp(e2); 
		  Employee e3 = new Employee(); e3.setEmpSal(45000.0f);
		  e3.setEmpName("Gundetii"); empserv.addEmp(e3);*/
		 

//		Employee ee =empserv.getEmpByID(10); 	//Getting details from table
//		System.out.println(ee);

		/*
		 * Employee ee =empserv.deleteEmpById(10); //Deleting System.out.println(ee);
		 */

		// Fetching all records
		/*ArrayList<Employee> eList = empserv.fetchAllEmp();
		for (Employee tempEmp : eList) {
			System.out.println(
					"ID: "+ tempEmp.getEmpId() +" Name:" + tempEmp.getEmpName() +" Salary:" + tempEmp.getEmpSal());
		}*/
		
		/*Employee e1= empserv.updateEmpSal(21, 5000);
		System.out.println(e1);*/
	}

}
