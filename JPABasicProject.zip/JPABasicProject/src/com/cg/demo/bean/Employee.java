package com.cg.demo.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@Entity   				// specify that employee class is a JPA entity
@Table(name="Employee")	//Used if tableName and ClassName is different 
public class Employee {
	
	@Id	//Mandatory annotation to map with primary column of database
	//@GeneratedValue(strategy=GenerationType.AUTO)  // Used to generated value automatically
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="seq",sequenceName="emp_seq1",allocationSize=1)      //used to generated sequence which is defined in sql
	@Column(name="emp_id",length=10)    	//Optional if both names are same.
	private int empId;
	@Column(name="emp_name" ,length=20)
	private String empName;
	@Column(name="emp_sal",length=15)
	private float empSal;
	
	
	@Column(name="emp_doj")
	@Temporal(TemporalType.DATE)
	//@Transient                                        //JPA will skip mapping with column
	private Date empDOJ;
	public Date getEmpDOJ() {
		return empDOJ;
	}


	public void setEmpDOJ(Date empDOJ) {
		this.empDOJ = empDOJ;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public float getEmpSal() {
		return empSal;
	}


	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}


	public Employee() {
		super();
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}


	

	
	
	
}
