package com.cg.demo.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.IGearDao;
import com.cg.demo.dto.QueryMaster;


@Service
@Transactional
public class GearServiceImpl  implements IGearService
{
	@Autowired
	IGearDao gearDao=null;

	public IGearDao getGearDao() {
		return gearDao;
	}

	public void setGearDao(IGearDao gearDao) {
		this.gearDao = gearDao;
	}

	@Override
	public ArrayList<QueryMaster> fetchAllUsers(int id1)
	{
		
		return gearDao.fetchAllUsers(id1);
	}

	@Override
	public void ModifyGearDetails(int id1,String sol)
	{
		 gearDao.ModifyGearDetails(id1,sol);
		
	}
	

}
