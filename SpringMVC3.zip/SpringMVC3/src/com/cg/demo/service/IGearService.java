package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.dto.QueryMaster;

public interface IGearService
{

	public ArrayList<QueryMaster> fetchAllUsers(int id1);

	public void ModifyGearDetails(int id1, String sol);

}
