package com.cg.pp.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;
import com.cg.pp.util.Database;

public class DaoClass implements DaoInterface {
	EntityManager manager;

	public DaoClass() {
		manager = Database.getEntityManager();
	}

	@Override
	public int addCustomer(Customer customer) throws SQLException {
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(customer);
		transaction.commit();
		return customer.getAccno();
	}

	@Override
	public Customer getCustomer(int accno) throws SQLException {
		Customer customer = manager.find(Customer.class, accno);
		return customer;
	}

	@Override
	public int addTransaction(int accno, Transaction txn) throws SQLException {
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		Customer customer = manager.find(Customer.class, accno);
		txn.setCustomer(customer);
		txn.setTxndate(Date.valueOf(LocalDate.now()));
		manager.persist(txn);
		transaction.commit();
		txn = manager.find(Transaction.class, txn.getTxnId());
		return txn.getTxnId();
	}

	@Override
	public List<Transaction> printTransactions(int accno) throws SQLException {
		List<Transaction> list = new ArrayList<>();
		String sql = "SELECT a FROM Transaction a where accno=?";
		TypedQuery<Transaction> query = manager.createQuery(sql, Transaction.class);
		query.setParameter(1, accno);
		list = query.getResultList();
		return list;
	}

	@Override
	public void updateCustomer(Customer customer) throws SQLException {
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		manager.merge(customer);
		transaction.commit();
	}

}
