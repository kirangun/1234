package com.cg.pp.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;
import com.cg.pp.exception.CustomerException;

public interface ServiceInterface {

	int addCustomer(Customer customer) throws SQLException;

	Customer getCustomer(int accno) throws SQLException;

	Transaction depositMoney(int accno, double amount) throws CustomerException, SQLException;

	Transaction withdrawMoney(int accno, double amount) throws CustomerException, SQLException;

	boolean verifyPassword(int accno, String password) throws CustomerException, SQLException;

	Transaction fundTransfer(int accno, int trg_accno, double amount) throws CustomerException, SQLException;

	List<Transaction> printTransactions(int accno) throws SQLException;

}
