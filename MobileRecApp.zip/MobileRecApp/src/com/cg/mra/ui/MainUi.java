package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUi {
	public static void main(String[] args) {
		AccountService ser= new AccountServiceImpl();
		
		Scanner scanner = new Scanner(System.in);
		do {
			System.out.println("#******************$$$*******************#");
			System.out.println("1.Account Balance Enquiry");
			System.out.println("2.Recharge Account");
			System.out.println("3.Exit");
			System.out.println("#******************$$$*******************#");
			System.out.println("Enter Choice");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Id");
				String accountid = scanner.next();
				Account acc=null;
				try {
					if(ser.validateAccountId(accountid))
					 acc=ser.getAccountDetails(accountid);
					System.out.println("Your Current balance is Rs. " + acc.getAccountBalance());
				} catch (MobileException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter Account id");
				accountid = scanner.next();
				System.out.println("Enter Amount to Recharge");
				Double rechargeAmount = scanner.nextDouble();
				int i=0;
				try {
					
					 i= ser.rechargeAccount(accountid, rechargeAmount);
					if (i == 1) {
						System.out.println("Recharge Succesful");
					}

				} catch (MobileException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 3:
				System.exit(0);
				break;

			default:
				break;
			}
		} while (true);
		
	}
}
