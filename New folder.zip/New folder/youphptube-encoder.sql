-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2019 at 01:02 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `youphptube-encoder`
--

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE `configurations` (
  `id` int(11) NOT NULL,
  `allowedStreamersURL` text DEFAULT NULL,
  `defaultPriority` int(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `version` varchar(10) DEFAULT NULL,
  `autodelete` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` (`id`, `allowedStreamersURL`, `defaultPriority`, `created`, `modified`, `version`, `autodelete`) VALUES
(1, 'http://localhost/app/', 1, '2019-08-08 16:19:24', '2019-08-08 16:19:24', '2.3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `encoder_queue`
--

CREATE TABLE `encoder_queue` (
  `id` int(11) NOT NULL,
  `fileURI` varchar(255) NOT NULL,
  `filename` varchar(400) NOT NULL,
  `status` enum('queue','encoding','error','done','downloading','transferring') DEFAULT NULL,
  `status_obs` varchar(255) DEFAULT NULL,
  `return_vars` varchar(45) DEFAULT NULL,
  `priority` int(1) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `videoDownloadedLink` varchar(255) DEFAULT NULL,
  `downloadedFileName` varchar(255) DEFAULT NULL,
  `streamers_id` int(11) NOT NULL,
  `formats_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `formats`
--

CREATE TABLE `formats` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `code` varchar(400) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `extension` varchar(5) DEFAULT NULL,
  `extension_from` varchar(5) DEFAULT NULL,
  `order` smallint(5) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `formats`
--

INSERT INTO `formats` (`id`, `name`, `code`, `created`, `modified`, `extension`, `extension_from`, `order`) VALUES
(1, 'MP4 Low', 'ffmpeg -i {$pathFileName} -vf scale=-2:360 -movflags faststart -preset ultrafast -vcodec h264 -acodec aac -strict -2 -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 10),
(2, 'WEBM Low', 'ffmpeg -i {$pathFileName} -vf scale=-2:360 -movflags faststart -preset ultrafast -f webm -c:v libvpx -b:v 1M -acodec libvorbis -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'webm', 'mp4', 20),
(3, 'MP3', 'ffmpeg -i {$pathFileName} -acodec libmp3lame -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp3', 'mp3', 30),
(4, 'OGG', 'ffmpeg -i {$pathFileName} -acodec libvorbis -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'ogg', 'mp3', 40),
(5, 'MP3 to Spectrum.MP4', 'ffmpeg -i {$pathFileName} -filter_complex \'[0:a]showwaves=s=640x360:mode=line,format=yuv420p[v]\' -map \'[v]\' -map 0:a -c:v libx264 -c:a copy {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp3', 50),
(6, 'Video.MP4 to Audio.MP3', 'ffmpeg -i {$pathFileName} -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp3', 'mp4', 60),
(7, 'MP4 SD', 'ffmpeg -i {$pathFileName} -vf scale=-2:540 -movflags faststart -preset ultrafast -vcodec h264 -acodec aac -strict -2 -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 11),
(8, 'MP4 HD', 'ffmpeg -i {$pathFileName} -vf scale=-2:720 -movflags faststart -preset ultrafast -vcodec h264 -acodec aac -strict -2 -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 12),
(9, 'WEBM SD', 'ffmpeg -i {$pathFileName} -vf scale=-2:540 -movflags faststart -preset ultrafast -f webm -c:v libvpx -b:v 1M -acodec libvorbis -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'webm', 'mp4', 21),
(10, 'WEBM HD', 'ffmpeg -i {$pathFileName} -vf scale=-2:720 -movflags faststart -preset ultrafast -f webm -c:v libvpx -b:v 1M -acodec libvorbis -y {$destinationFile}', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'webm', 'mp4', 22),
(11, 'Video to Spectrum', '60-50-10', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 70),
(12, 'Video to Audio', '60-40', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp3', 'mp4', 71),
(13, 'Both Video', '10-20', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 72),
(14, 'Both Audio', '30-40', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp3', 'mp3', 73),
(15, 'MP4 Low', '10', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 74),
(16, 'MP4 SD', '11', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 75),
(17, 'MP4 HD', '12', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 76),
(18, 'MP4 Low SD', '10-11', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 77),
(19, 'MP4 SD HD', '11-12', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 78),
(20, 'MP4 Low HD', '10 12', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 79),
(21, 'MP4 Low SD HD', '10-11-12', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 80),
(22, 'Both Low', '10-20', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 81),
(23, 'Both SD', '11-21', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 82),
(24, 'Both HD', '12-22', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 83),
(25, 'Both Low SD', '10-11-20-21', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 84),
(26, 'Both SD HD', '11-12-21-22', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 85),
(27, 'Both Low HD', '10-12-20-22', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 86),
(28, 'Both Low SD HD', '10-11-12-20-21-22', '2019-08-08 16:19:24', '2019-08-08 16:19:24', 'mp4', 'mp4', 87);

-- --------------------------------------------------------

--
-- Table structure for table `streamers`
--

CREATE TABLE `streamers` (
  `id` int(11) NOT NULL,
  `siteURL` varchar(255) NOT NULL,
  `user` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT 3,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `streamers`
--

INSERT INTO `streamers` (`id`, `siteURL`, `user`, `pass`, `priority`, `isAdmin`, `created`, `modified`) VALUES
(1, 'http://localhost/app/', 'admin', 'ce48f3d53ea7893375edc5f47b369ca0', 1, 1, '2019-08-08 16:19:24', '2019-08-08 12:49:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `configurations`
--
ALTER TABLE `configurations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `encoder_queue`
--
ALTER TABLE `encoder_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_encoder_queue_formats_idx` (`formats_id`),
  ADD KEY `fk_encoder_queue_streamers1_idx` (`streamers_id`);

--
-- Indexes for table `formats`
--
ALTER TABLE `formats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `streamers`
--
ALTER TABLE `streamers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `encoder_queue`
--
ALTER TABLE `encoder_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formats`
--
ALTER TABLE `formats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `streamers`
--
ALTER TABLE `streamers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `encoder_queue`
--
ALTER TABLE `encoder_queue`
  ADD CONSTRAINT `fk_encoder_queue_formats` FOREIGN KEY (`formats_id`) REFERENCES `formats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_encoder_queue_streamers1` FOREIGN KEY (`streamers_id`) REFERENCES `streamers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
