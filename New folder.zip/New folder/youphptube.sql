-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2019 at 12:35 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `youphptube`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `clean_name` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `nextVideoOrder` int(2) NOT NULL DEFAULT 0,
  `parentId` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `iconClass` varchar(45) NOT NULL DEFAULT 'fa fa-folder',
  `users_id` int(11) NOT NULL DEFAULT 1,
  `private` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `clean_name`, `description`, `nextVideoOrder`, `parentId`, `created`, `modified`, `iconClass`, `users_id`, `private`) VALUES
(1, 'Default', 'default', '', 0, 0, '2019-08-08 15:25:25', '2019-08-08 15:25:25', 'fa fa-folder', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `category_type_cache`
--

CREATE TABLE `category_type_cache` (
  `categoryId` int(11) NOT NULL,
  `type` int(2) NOT NULL DEFAULT 0 COMMENT '0=both, 1=audio, 2=video',
  `manualSet` int(1) NOT NULL DEFAULT 0 COMMENT '0=auto, 1=manual'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_type_cache`
--

INSERT INTO `category_type_cache` (`categoryId`, `type`, `manualSet`) VALUES
(1, 2, 0),
(2, 0, 0),
(3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `videos_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `comments_id_pai` int(11) DEFAULT NULL,
  `pin` int(1) NOT NULL DEFAULT 0 COMMENT 'If = 1 will be on the top'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `comments_likes`
--

CREATE TABLE `comments_likes` (
  `id` int(11) NOT NULL,
  `like` int(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `comments_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE `configurations` (
  `id` int(11) NOT NULL,
  `video_resolution` varchar(12) NOT NULL,
  `users_id` int(11) NOT NULL,
  `version` varchar(10) NOT NULL,
  `webSiteTitle` varchar(45) NOT NULL DEFAULT 'YouPHPTube',
  `language` varchar(6) NOT NULL DEFAULT 'en',
  `contactEmail` varchar(45) NOT NULL,
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  `authGoogle_id` varchar(255) DEFAULT NULL,
  `authGoogle_key` varchar(255) DEFAULT NULL,
  `authGoogle_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `authFacebook_id` varchar(255) DEFAULT NULL,
  `authFacebook_key` varchar(255) DEFAULT NULL,
  `authFacebook_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `authCanUploadVideos` tinyint(1) NOT NULL DEFAULT 0,
  `authCanViewChart` tinyint(2) NOT NULL DEFAULT 0,
  `authCanComment` tinyint(1) NOT NULL DEFAULT 1,
  `head` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `logo_small` varchar(255) DEFAULT NULL,
  `adsense` text DEFAULT NULL,
  `mode` enum('Youtube','Gallery') DEFAULT 'Youtube',
  `disable_analytics` tinyint(1) DEFAULT 0,
  `disable_youtubeupload` tinyint(1) DEFAULT 0,
  `allow_download` tinyint(1) DEFAULT 0,
  `session_timeout` int(11) DEFAULT 3600,
  `autoplay` tinyint(1) DEFAULT NULL,
  `theme` varchar(45) DEFAULT 'default',
  `smtp` tinyint(1) DEFAULT NULL,
  `smtpAuth` tinyint(1) DEFAULT NULL,
  `smtpSecure` varchar(255) DEFAULT NULL COMMENT '''ssl''; // secure transfer enabled REQUIRED for Gmail',
  `smtpHost` varchar(255) DEFAULT NULL COMMENT '"smtp.gmail.com"',
  `smtpUsername` varchar(255) DEFAULT NULL COMMENT '"email@gmail.com"',
  `smtpPassword` varchar(255) DEFAULT NULL,
  `smtpPort` int(11) DEFAULT NULL,
  `encoderURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` (`id`, `video_resolution`, `users_id`, `version`, `webSiteTitle`, `language`, `contactEmail`, `modified`, `created`, `authGoogle_id`, `authGoogle_key`, `authGoogle_enabled`, `authFacebook_id`, `authFacebook_key`, `authFacebook_enabled`, `authCanUploadVideos`, `authCanViewChart`, `authCanComment`, `head`, `logo`, `logo_small`, `adsense`, `mode`, `disable_analytics`, `disable_youtubeupload`, `allow_download`, `session_timeout`, `autoplay`, `theme`, `smtp`, `smtpAuth`, `smtpSecure`, `smtpHost`, `smtpUsername`, `smtpPassword`, `smtpPort`, `encoderURL`) VALUES
(1, '858:480', 1, '7.3', 'MyPHPTube', 'en', 'admin@host.com', '2019-08-08 15:25:25', '2019-08-08 15:25:25', NULL, NULL, 0, NULL, NULL, 0, 0, 0, 1, '', 'videos/userPhoto/logo.png', 'view/img/logo32.png', '', 'Youtube', 0, 0, 0, 3600, 0, 'default', 0, 0, '', '', '', '', 0, 'https://encoder.youphptube.com/');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `like` int(1) NOT NULL DEFAULT 0 COMMENT '1 = Like\n0 = Does not metter\n-1 = Dislike',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `videos_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `playlists`
--

CREATE TABLE `playlists` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `status` enum('public','private','unlisted','favorite','watch_later') NOT NULL DEFAULT 'public'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `playlists_has_videos`
--

CREATE TABLE `playlists_has_videos` (
  `playlists_id` int(11) NOT NULL,
  `videos_id` int(11) NOT NULL,
  `order` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE `plugins` (
  `id` int(11) NOT NULL,
  `uuid` varchar(45) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `object_data` text DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `dirName` varchar(255) NOT NULL,
  `pluginversion` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plugins`
--

INSERT INTO `plugins` (`id`, `uuid`, `status`, `created`, `modified`, `object_data`, `name`, `dirName`, `pluginversion`) VALUES
(1, '55a4fa56-8a30-48d4-a0fb-8aa6b3f69033', 'active', '2019-08-08 11:55:54', '2019-08-08 12:00:35', '{\"logoMenuBarURL\":\"http://localhost/app/\",\"encoderNetwork\":\"https://network.youphptube.com/\",\"useEncoderNetworkRecomendation\":false,\"doNotShowEncoderNetwork\":true,\"doNotShowUploadButton\":false,\"uploadButtonDropdownIcon\":\"fas fa-video\",\"uploadButtonDropdownText\":\"\",\"encoderNetworkLabel\":\"\",\"doNotShowUploadMP4Button\":false,\"uploadMP4ButtonLabel\":\"\",\"doNotShowImportMP4Button\":false,\"importMP4ButtonLabel\":\"\",\"doNotShowEncoderButton\":false,\"encoderButtonLabel\":\"\",\"doNotShowEmbedButton\":false,\"embedBackgroundColor\":\"white\",\"embedButtonLabel\":\"\",\"doNotShowEncoderHLS\":false,\"doNotShowEncoderResolutionLow\":false,\"doNotShowEncoderResolutionSD\":false,\"doNotShowEncoderResolutionHD\":false,\"doNotShowLeftMenuAudioAndVideoButtons\":false,\"doNotShowWebsiteOnContactForm\":false,\"doNotUseXsendFile\":false,\"makeVideosInactiveAfterEncode\":false,\"usePermalinks\":false,\"showAdsenseBannerOnTop\":false,\"showAdsenseBannerOnLeft\":true,\"disableAnimatedGif\":false,\"removeBrowserChannelLinkFromMenu\":false,\"EnableWavesurfer\":false,\"EnableMinifyJS\":false,\"disableShareAndPlaylist\":false,\"commentsMaxLength\":\"200\",\"disableYoutubePlayerIntegration\":false,\"utf8Encode\":false,\"utf8Decode\":false,\"menuBarHTMLCode\":{\"type\":\"textarea\",\"value\":\"\"},\"underMenuBarHTMLCode\":{\"type\":\"textarea\",\"value\":\"\"},\"footerHTMLCode\":{\"type\":\"textarea\",\"value\":\"\"},\"signInOnRight\":true,\"signInOnLeft\":true,\"forceCategory\":false,\"autoPlayAjax\":false,\"disableHelpLeftMenu\":false,\"disableAboutLeftMenu\":false,\"disableContactLeftMenu\":false,\"disableNavbar\":false,\"videosCDN\":\"\",\"useFFMPEGToGenerateThumbs\":false,\"showImageDownloadOption\":false,\"doNotDisplayViews\":false,\"doNotDisplayLikes\":false,\"doNotDisplayCategoryLeftMenu\":false,\"doNotDisplayCategory\":false,\"doNotDisplayGroupsTags\":false,\"doNotDisplayPluginsTags\":false,\"showNotRatedLabel\":false,\"askRRatingConfirmationBeforePlay_G\":false,\"askRRatingConfirmationBeforePlay_PG\":false,\"askRRatingConfirmationBeforePlay_PG13\":false,\"askRRatingConfirmationBeforePlay_R\":false,\"askRRatingConfirmationBeforePlay_NC17\":true,\"askRRatingConfirmationBeforePlay_MA\":true,\"AsyncJobs\":false,\"doNotShowLeftHomeButton\":false,\"doNotShowLeftTrendingButton\":false,\"CategoryLabel\":\"Categories\",\"ShowAllVideosOnCategory\":false,\"paidOnlyUsersTellWhatVideoIs\":false,\"paidOnlyShowLabels\":false,\"paidOnlyLabel\":\"Premium\",\"paidOnlyFreeLabel\":\"Free\",\"removeSubscribeButton\":false,\"removeThumbsUpAndDown\":false,\"videoNotFoundText\":{\"type\":\"textarea\",\"value\":\"\"}}', 'CustomizeAdvanced', 'CustomizeAdvanced', '1.0'),
(2, '55a4fa56-8a30-48d4-a0fb-8aa6b3fuser3', 'active', '2019-08-08 11:55:56', '2019-08-08 12:00:07', '{\"userCanAllowFilesDownload\":false,\"userCanAllowFilesShare\":false,\"userCanAllowFilesDownloadSelectPerVideo\":false,\"userCanAllowFilesShareSelectPerVideo\":false,\"usersCanCreateNewCategories\":false,\"userCanNotChangeCategory\":false,\"userMustBeLoggedIn\":false,\"onlyVerifiedEmailCanUpload\":false,\"sendVerificationMailAutomaic\":false,\"unverifiedEmailsCanNOTLogin\":false,\"newUsersCanStream\":false,\"doNotIndentifyByEmail\":false,\"doNotIndentifyByName\":false,\"doNotIndentifyByUserName\":false,\"hideRemoveChannelFromModeYoutube\":false,\"showChannelBannerOnModeYoutube\":false,\"encryptPasswordsWithSalt\":false,\"requestCaptchaAfterLoginsAttempts\":\"0\",\"disableSignOutButton\":false,\"disableNativeSignUp\":true,\"disableNativeSignIn\":false,\"disablePersonalInfo\":true,\"signInOnRight\":true,\"doNotShowRightProfile\":true,\"doNotShowLeftProfile\":false,\"forceLoginToBeTheEmail\":false,\"messageToAppearBelowLoginBox\":{\"type\":\"textarea\",\"value\":\"\"},\"doNotShowTopBannerOnChannel\":false,\"doNotShowMyChannelNameOnBasicInfo\":false,\"doNotShowMyAnalyticsCodeOnBasicInfo\":false,\"doNotShowMyAboutOnBasicInfo\":false,\"MyChannelLabel\":\"My Channel\",\"afterLoginGoToMyChannel\":false}', 'CustomizeUser', 'CustomizeUser', '1.0'),
(3, 'a06505bf-3570-4b1f-977a-fd0e5cab205d', 'active', '2019-08-08 11:58:28', '2019-08-08 11:58:28', NULL, 'Gallery', 'Gallery', '1.0'),
(4, 'youu05bf-3570-4b1f-977a-fd0e5cabtube', 'inactive', '2019-08-08 11:58:28', '2019-08-08 11:58:28', NULL, 'YouTube', 'YouTube', '1.0'),
(5, 'e3a568e6-ef61-4dcc-aad0-0109e9be8e36', 'inactive', '2019-08-08 11:58:28', '2019-08-08 11:58:28', NULL, 'YouPHPFlix2', 'YouPHPFlix2', '1.0'),
(6, '2e7866ed-2e02-4136-bec6-4cd90754e3a2', 'active', '2019-08-08 11:58:57', '2019-08-08 11:58:57', NULL, 'TopMenu', 'TopMenu', '2.1'),
(7, 'f5c30980-9530-4650-8eab-9ab461ea6fdb', 'active', '2019-08-08 11:59:11', '2019-08-08 11:59:11', NULL, 'SeekButton', 'SeekButton', '1.0'),
(8, '5310b394-b54f-48ab-9049-995df4d95239', 'active', '2019-08-08 11:59:17', '2019-08-08 11:59:17', NULL, 'NextButton', 'NextButton', '1.0');

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `secret` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subscribes`
--

CREATE TABLE `subscribes` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` enum('a','i') NOT NULL DEFAULT 'a',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT 1 COMMENT 'subscribes to user channel',
  `notify` tinyint(1) NOT NULL DEFAULT 1,
  `subscriber_users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user` varchar(45) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(145) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('a','i') NOT NULL DEFAULT 'a',
  `photoURL` varchar(255) DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `recoverPass` varchar(255) DEFAULT NULL,
  `backgroundURL` varchar(255) DEFAULT NULL,
  `canStream` tinyint(1) DEFAULT NULL,
  `canUpload` tinyint(1) DEFAULT NULL,
  `canViewChart` tinyint(1) NOT NULL DEFAULT 0,
  `about` text DEFAULT NULL,
  `channelName` varchar(45) DEFAULT NULL,
  `emailVerified` tinyint(1) NOT NULL DEFAULT 0,
  `analyticsCode` varchar(45) DEFAULT NULL,
  `externalOptions` text DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `zip_code` varchar(45) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user`, `name`, `email`, `password`, `created`, `modified`, `isAdmin`, `status`, `photoURL`, `lastLogin`, `recoverPass`, `backgroundURL`, `canStream`, `canUpload`, `canViewChart`, `about`, `channelName`, `emailVerified`, `analyticsCode`, `externalOptions`, `first_name`, `last_name`, `address`, `zip_code`, `country`, `region`, `city`) VALUES
(1, 'admin', 'Administrator', 'admin@host.com', 'ce48f3d53ea7893375edc5f47b369ca0', '2019-08-08 15:25:25', '2019-08-08 15:33:57', 1, 'a', 'videos/userPhoto/photo1.png', '2019-08-08 15:33:57', NULL, 'videos/userPhoto/background1.png', 0, 0, 0, '', '5d4bf19dc9afd', 0, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_blob`
--

CREATE TABLE `users_blob` (
  `id` int(11) NOT NULL,
  `blob` longblob DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users_has_users_groups`
--

CREATE TABLE `users_has_users_groups` (
  `users_id` int(11) NOT NULL,
  `users_groups_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `title` varchar(190) NOT NULL,
  `clean_title` varchar(190) NOT NULL,
  `description` text DEFAULT NULL,
  `views_count` int(11) NOT NULL DEFAULT 0,
  `views_count_25` int(11) DEFAULT 0,
  `views_count_50` int(11) DEFAULT 0,
  `views_count_75` int(11) DEFAULT 0,
  `views_count_100` int(11) DEFAULT 0,
  `status` enum('a','i','e','x','d','xmp4','xwebm','xmp3','xogg','ximg','u','p') NOT NULL DEFAULT 'e' COMMENT 'a = active\ni = inactive\ne = encoding\nx = encoding error\nd = downloading\nu = Unlisted\np = private\nxmp4 = encoding mp4 error \nxwebm = encoding webm error \nxmp3 = encoding mp3 error \nxogg = encoding ogg error \nximg = get image error',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `users_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `duration` varchar(15) NOT NULL,
  `type` enum('audio','video','embed','linkVideo','linkAudio','torrent') NOT NULL DEFAULT 'video',
  `videoDownloadedLink` varchar(255) DEFAULT NULL,
  `order` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `rotation` smallint(6) DEFAULT 0,
  `zoom` float DEFAULT 1,
  `youtubeId` varchar(45) DEFAULT NULL,
  `videoLink` varchar(255) DEFAULT NULL,
  `next_videos_id` int(11) DEFAULT NULL,
  `isSuggested` int(1) NOT NULL DEFAULT 0,
  `trailer1` varchar(255) DEFAULT NULL,
  `trailer2` varchar(255) DEFAULT NULL,
  `trailer3` varchar(255) DEFAULT NULL,
  `rate` float(4,2) DEFAULT NULL,
  `can_download` tinyint(1) DEFAULT NULL,
  `can_share` tinyint(1) DEFAULT NULL,
  `rrating` varchar(45) DEFAULT NULL,
  `externalOptions` text DEFAULT NULL,
  `only_for_paid` tinyint(1) DEFAULT NULL,
  `sites_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `clean_title`, `description`, `views_count`, `views_count_25`, `views_count_50`, `views_count_75`, `views_count_100`, `status`, `created`, `modified`, `users_id`, `categories_id`, `filename`, `duration`, `type`, `videoDownloadedLink`, `order`, `rotation`, `zoom`, `youtubeId`, `videoLink`, `next_videos_id`, `isSuggested`, `trailer1`, `trailer2`, `trailer3`, `rate`, `can_download`, `can_share`, `rrating`, `externalOptions`, `only_for_paid`, `sites_id`) VALUES
(1, 'Video automatically booked', 'video-automatically-booked', '', 1, 0, 0, 0, 0, 'a', '2019-08-08 12:00:40', '2019-08-08 12:01:01', 1, 1, 'SampleVideo1280x72030mb_5d4bf2d74d1971.46733131', '0:02:51', 'video', '', 1, 0, 1, '', '', NULL, 0, '', '', '', 0.00, 0, 0, '', '{\"videoStartSeconds\":\"00:00:00\"}', 0, NULL),
(2, 'Video automatically booked', 'video-automatically-booked-1', '', 0, 0, 0, 0, 0, 'a', '2019-08-08 12:01:05', '2019-08-08 12:01:13', 1, 1, 'SampleVideo1280x72020mb_5d4bf2e845b861.91379848', '0:01:57', 'video', '', 1, 0, 1, '', '', NULL, 0, '', '', '', 0.00, 0, 0, '', '{\"videoStartSeconds\":\"00:00:00\"}', 0, NULL),
(3, 'Video automatically booked', 'video-automatically-booked-2', '', 0, 0, 0, 0, 0, 'a', '2019-08-08 12:01:19', '2019-08-08 12:01:26', 1, 1, 'SampleVideo1280x7202mb_5d4bf2f55537e0.66645440', '0:00:14', 'video', '', 1, 0, 1, '', '', NULL, 0, '', '', '', 0.00, 0, 0, '', '{\"videoStartSeconds\":\"00:00:00\"}', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `videos_group_view`
--

CREATE TABLE `videos_group_view` (
  `id` int(11) NOT NULL,
  `users_groups_id` int(11) NOT NULL,
  `videos_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `videos_statistics`
--

CREATE TABLE `videos_statistics` (
  `id` int(11) NOT NULL,
  `when` datetime NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `videos_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `lastVideoTime` int(11) DEFAULT NULL,
  `session_id` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videos_statistics`
--

INSERT INTO `videos_statistics` (`id`, `when`, `ip`, `users_id`, `videos_id`, `created`, `modified`, `lastVideoTime`, `session_id`) VALUES
(1, '2019-08-08 12:01:02', '::1', 1, 1, '2019-08-08 12:01:02', '2019-08-08 12:01:02', 0, 'pqhepuubplj06eumqjvaqba0j2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clean_name_UNIQUE` (`clean_name`),
  ADD KEY `fk_categories_users1_idx` (`users_id`);

--
-- Indexes for table `category_type_cache`
--
ALTER TABLE `category_type_cache`
  ADD UNIQUE KEY `categoryId` (`categoryId`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_comments_videos1_idx` (`videos_id`),
  ADD KEY `fk_comments_users1_idx` (`users_id`),
  ADD KEY `fk_comments_comments1_idx` (`comments_id_pai`);

--
-- Indexes for table `comments_likes`
--
ALTER TABLE `comments_likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_comments_likes_users1_idx` (`users_id`),
  ADD KEY `fk_comments_likes_comments1_idx` (`comments_id`);

--
-- Indexes for table `configurations`
--
ALTER TABLE `configurations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_configurations_users1_idx` (`users_id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_likes_videos1_idx` (`videos_id`),
  ADD KEY `fk_likes_users1_idx` (`users_id`);

--
-- Indexes for table `playlists`
--
ALTER TABLE `playlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_playlists_users1_idx` (`users_id`);

--
-- Indexes for table `playlists_has_videos`
--
ALTER TABLE `playlists_has_videos`
  ADD PRIMARY KEY (`playlists_id`,`videos_id`),
  ADD KEY `fk_playlists_has_videos_videos1_idx` (`videos_id`),
  ADD KEY `fk_playlists_has_videos_playlists1_idx` (`playlists_id`);

--
-- Indexes for table `plugins`
--
ALTER TABLE `plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid_UNIQUE` (`uuid`),
  ADD KEY `plugin_status` (`status`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribes`
--
ALTER TABLE `subscribes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_subscribes_users1_idx` (`users_id`),
  ADD KEY `fk_subscribes_users2_idx` (`subscriber_users_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_UNIQUE` (`user`);

--
-- Indexes for table `users_blob`
--
ALTER TABLE `users_blob`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_users_document_image_users1_idx` (`users_id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_has_users_groups`
--
ALTER TABLE `users_has_users_groups`
  ADD PRIMARY KEY (`users_id`,`users_groups_id`),
  ADD UNIQUE KEY `index_user_groups_unique` (`users_groups_id`,`users_id`),
  ADD KEY `fk_users_has_users_groups_users_groups1_idx` (`users_groups_id`),
  ADD KEY `fk_users_has_users_groups_users1_idx` (`users_id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clean_title_UNIQUE` (`clean_title`),
  ADD KEY `fk_videos_users_idx` (`users_id`),
  ADD KEY `fk_videos_categories1_idx` (`categories_id`),
  ADD KEY `index5` (`order`),
  ADD KEY `fk_videos_videos1_idx` (`next_videos_id`),
  ADD KEY `fk_videos_sites1_idx` (`sites_id`),
  ADD KEY `videos_status_index` (`status`),
  ADD KEY `is_suggested_index` (`isSuggested`),
  ADD KEY `views_count_index` (`views_count`),
  ADD KEY `filename_index` (`filename`);

--
-- Indexes for table `videos_group_view`
--
ALTER TABLE `videos_group_view`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_videos_group_view_users_groups1_idx` (`users_groups_id`),
  ADD KEY `fk_videos_group_view_videos1_idx` (`videos_id`);

--
-- Indexes for table `videos_statistics`
--
ALTER TABLE `videos_statistics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_videos_statistics_users1_idx` (`users_id`),
  ADD KEY `fk_videos_statistics_videos1_idx` (`videos_id`),
  ADD KEY `when_statisci` (`when`),
  ADD KEY `session_id_statistics` (`session_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments_likes`
--
ALTER TABLE `comments_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `playlists`
--
ALTER TABLE `playlists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plugins`
--
ALTER TABLE `plugins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sites`
--
ALTER TABLE `sites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscribes`
--
ALTER TABLE `subscribes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users_blob`
--
ALTER TABLE `users_blob`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `videos_group_view`
--
ALTER TABLE `videos_group_view`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `videos_statistics`
--
ALTER TABLE `videos_statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `fk_categories_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `fk_comments_comments1` FOREIGN KEY (`comments_id_pai`) REFERENCES `comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_comments_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_comments_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `comments_likes`
--
ALTER TABLE `comments_likes`
  ADD CONSTRAINT `fk_comments_likes_comments1` FOREIGN KEY (`comments_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_comments_likes_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `configurations`
--
ALTER TABLE `configurations`
  ADD CONSTRAINT `fk_configurations_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `fk_likes_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_likes_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `playlists`
--
ALTER TABLE `playlists`
  ADD CONSTRAINT `fk_playlists_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `playlists_has_videos`
--
ALTER TABLE `playlists_has_videos`
  ADD CONSTRAINT `fk_playlists_has_videos_playlists1` FOREIGN KEY (`playlists_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_playlists_has_videos_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subscribes`
--
ALTER TABLE `subscribes`
  ADD CONSTRAINT `fk_subscribes_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_subscribes_users2` FOREIGN KEY (`subscriber_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_blob`
--
ALTER TABLE `users_blob`
  ADD CONSTRAINT `fk_users_document_image_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_has_users_groups`
--
ALTER TABLE `users_has_users_groups`
  ADD CONSTRAINT `fk_users_has_users_groups_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_users_has_users_groups_users_groups1` FOREIGN KEY (`users_groups_id`) REFERENCES `users_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `videos`
--
ALTER TABLE `videos`
  ADD CONSTRAINT `fk_videos_categories1` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_videos_sites1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_videos_users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_videos_videos1` FOREIGN KEY (`next_videos_id`) REFERENCES `videos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `videos_group_view`
--
ALTER TABLE `videos_group_view`
  ADD CONSTRAINT `fk_videos_group_view_users_groups1` FOREIGN KEY (`users_groups_id`) REFERENCES `users_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_videos_group_view_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `videos_statistics`
--
ALTER TABLE `videos_statistics`
  ADD CONSTRAINT `fk_videos_statistics_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_videos_statistics_videos1` FOREIGN KEY (`videos_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
