package com.cg.mra.service;

import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileException;

public class AccountServiceImpl implements AccountService {
	AccountDao dao = new AccountDaoImpl();


	@Override
	public Account getAccountDetails(String accId) throws MobileException {
		return dao.getAccountDetails(accId);
	}


	@Override
	public int rechargeAccount(String accId, Double rechargeAmount) throws MobileException {
		return dao.rechargeAccount(accId,rechargeAmount);
	}


	@Override
	public boolean validateAccountId(String accId) throws MobileException {
		Boolean flag=true;
		if(!Pattern.matches("^[0-9]{3}$",accId))
		{
			flag=false;
			throw new MobileException("Please Enter Valid AccountNumber \n eg:101");
			
		}
		return flag;
	}



}
