package com.cg.mra.dao;

import static org.junit.Assert.assertNotNull;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;

public class ValidateAccountDaoImpl {

	static Account acc;
	static AccountDao Dao;
	static AccountDaoImpl dao;
	@BeforeClass
	public static void init()
	{		
		acc=new Account("101","Pre Paid","John Shan",500.00);
		Dao= new AccountDaoImpl();
	
	}
	
	@Test
	public void TestToGetAllDetails() throws MobileException
	{

		assertNotNull(Dao.getAccountDetails(acc.getAccountId()));


	}
	
	
}
