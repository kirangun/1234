package com.cg.ex.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ex.bean.Employee;

public class Test {

	public static void main(String[] args) {
		ApplicationContext apx = new ClassPathXmlApplicationContext("cg.xml");
		Employee emp = (Employee) apx.getBean("emp1");
		System.out.println(emp);
		
		Employee emp2 = (Employee) apx.getBean("emp2");
		System.out.println(emp2.getSbuDetails());
	}

}
