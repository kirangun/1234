package com.cg.ex.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author kigundet
 *
 */
@Component("emp2")
public class Employee {
	@Value("177828")
	private int empId;
	@Value("Kiran")
	private String empName;
	@Value("2000") 
	private double salary;
	@Value("25")
	private int age;
	@Autowired
	private SBU sbu;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public SBU getSbuDetails() {
		
		return sbu;
		
	}
	public SBU getSbu() {
		return sbu;
	}
	public void setSbu(SBU sbu) {
		this.sbu = sbu;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", age=" + age + ", sbu="
				+ sbu + "]";
	}
	  
	
	
	
}
