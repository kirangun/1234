package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.demo.bean.Employee;
import com.cg.demo.util.JPAUtil;

public class EmployeeDaoImpl implements IEmployee {

	EntityManager em=null;
	EntityTransaction trans= null;
	public EmployeeDaoImpl() {						/*Persist insert
													merge
													remove	find(based on primary column)*/	
	}

	
	@Override
	public Employee addEmployee(Employee ee) {
		em=JPAUtil.getEntityManager();
		trans=em.getTransaction(); //get transcation 
		trans.begin();   //begin transcation
		em.persist(ee);
		trans.commit();
		System.out.println("Data is inserted in the table");
		Employee e1=em.find(Employee.class, ee.getEmpId());
		return e1;
	}
	@Override
	public Employee getEmpByID(int empId) {
		em=JPAUtil.getEntityManager();
		Employee e1= em.find(Employee.class,empId);
		return e1;
	}


	@Override
	public Employee deleteEmpById(int empId) {
		em=JPAUtil.getEntityManager();
		Employee ee = em.find(Employee.class, empId);
		trans=em.getTransaction();
		trans.begin();
		em.remove(ee);
		trans.commit();
		return ee;
	}


	@Override
	public ArrayList<Employee> fetchAllEmp() {
		String query = "SELECT emps FROM Employee emps";							// FETCHING ALL QUERIES
		em = JPAUtil.getEntityManager();
		TypedQuery<Employee> tyQry = em.createQuery(query, Employee.class);
		ArrayList<Employee> empList = (ArrayList<Employee>) tyQry.getResultList();
		return empList;
	}


	@Override
	public Employee updateEmpSal(int empId, float newSal) {
		float updatedSal = 0;
		em = JPAUtil.getEntityManager();
		trans = em.getTransaction();
		Employee emp1 = em.find(Employee.class, empId);
		updatedSal = emp1.getEmpSal() + newSal;
		emp1.setEmpSal(updatedSal);
		trans.begin();
		em.merge(emp1);
		trans.commit();
		System.out.println("Salary is updated for : " + empId);
		return emp1;
	}
	
	
}

