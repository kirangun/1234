package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Employee;

public interface IEmployeeService {
	public Employee addEmp(Employee ee);
	public Employee getEmpByID(int empId);
	public Employee deleteEmpById(int empId);
	public ArrayList<Employee> fetchAllEmp();
	public Employee updateEmpSal(int empId,float newSal);
}
