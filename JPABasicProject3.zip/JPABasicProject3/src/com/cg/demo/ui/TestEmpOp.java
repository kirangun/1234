package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.demo.bean.Employee;
import com.cg.demo.service.EmployeeServiceImpl;
import com.cg.demo.service.IEmployeeService;

public class TestEmpOp {

	public static void main(String[] args) {
		
		IEmployeeService empserv = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1.Insert");
			System.out.println("2.Get Details");
			System.out.println("3.Delete");
			System.out.println("4.Fetching all Employees");
			System.out.println("Enter Choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				Employee e = new Employee();
				System.out.println("Enter Employee Name");
				String name = sc.next();
				System.out.println("Enter Employee Salary");
				float sal = sc.nextFloat();
				e.setEmpName(name);
				e.setEmpSal(sal);
				empserv.addEmp(e);
				System.out.println("Employee added Successfully with id:"+e.getEmpId());
				break;
			case 2:

				System.out.println("Enter Id to display");
				e = empserv.getEmpByID(sc.nextInt());
				System.out.println("Employee Id= " +e.getEmpId()+ "Employee Name= " +e.getEmpName()+ "Employee Salary= " +e.getEmpSal());
				break;
			case 3:
				System.out.println("Enter Id to delete");
				e = empserv.deleteEmpById(sc.nextInt());
				System.out.println("Employee"+e.getEmpId()+"deleted");
				break;
			case 4:
				ArrayList<Employee> emp = empserv.fetchAllEmp();
				for (Employee employee : emp) {
					System.out.println(employee);
				}
			case 5: 
			}
		} while (true);
	}
}
	

