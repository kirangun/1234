package com.cg.demo.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity   				// specify that employee class is a JPA entity
@Table(name="Employee")	//Used if tableName and ClassName is different 
public class Employee {
	
	@Id	//Mandatory annotation to map with primary column of database
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="emp_id",length=10)    	//Optional if both names are same.
	private int empId;
	@Column(name="emp_name" ,length=20)
	private String empName;
	@Column(name="emp_sal",length=15)
	private float empSal;
	
	
	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public float getEmpSal() {
		return empSal;
	}


	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}


	public Employee() {
		super();
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}


	

	
	
	
}
