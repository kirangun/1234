package com.cg.hotel.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author kigundet
 *
 */
@Entity
@Table(name="hoteldetails")
public class Hotel {
	@Id
	@Column(name ="id",length = 20)
	private int hotelId;
	@Column(name="name",length = 20)
	private String hotelName;
	@Column(name="rating",length = 20)
	private String hotelRating;
	@Column(name="rate",length = 20)
	private int hotelRate;
	@Column(length = 20)
	private int availableRooms;
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelRating() {
		return hotelRating;
	}
	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}
	public int getHotelRate() {
		return hotelRate;
	}
	public void setHotelRate(int hotelRate) {
		this.hotelRate = hotelRate;
	}
	public int getAvailableRooms() {
		return availableRooms;
	}
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelRating=" + hotelRating
				+ ", hotelRate=" + hotelRate + ", availableRooms=" + availableRooms + "]";
	}
	
	
	
}
