package com.cg.hotel.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hotel.beans.Hotel;
import com.cg.hotel.service.IBookingService;


@Controller
public class BookingController {
		@Autowired
		IBookingService service;

		public IBookingService getService() {
			return service;
		}

		public void setService(IBookingService service) {
			this.service = service;
		}

		@RequestMapping("/hotelDetails")
		public String showHome(Model model) {
			Hotel hotel = new Hotel();
			ArrayList<Hotel> uList= service.fetchAllDetails();
			model.addAttribute("hotel",uList);
			return "hotelDetails";
			
		}
		@RequestMapping("/booking")
		public String booking(Model model ,@RequestParam("hnm") String name ) {
			model.addAttribute("hotel",name);
			return "HotelBookingSuccessPage";
			
		}
}
