package com.cg.hotel.service;

import java.util.ArrayList;

import com.cg.hotel.beans.Hotel;

public interface IBookingService {

	ArrayList<Hotel> fetchAllDetails();

}
