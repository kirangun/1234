package com.cg.hotel.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotel.beans.Hotel;
import com.cg.hotel.dao.IBookingDao;
@Service
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IBookingDao dao;
	
	
	@Override
	public ArrayList<Hotel> fetchAllDetails() {
		
		return dao.fetchAllDetails();
	}

}
