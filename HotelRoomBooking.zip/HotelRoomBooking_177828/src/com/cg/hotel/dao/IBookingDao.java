package com.cg.hotel.dao;

import java.util.ArrayList;

import com.cg.hotel.beans.Hotel;

public interface IBookingDao {

	ArrayList<Hotel> fetchAllDetails();

}
