package com.cg.hotel.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hotel.beans.Hotel;
@Transactional
@Repository
public class BookingDaoImpl implements IBookingDao {
	
	@PersistenceContext  																				// It will inject entitymgr object in present class
	EntityManager em = null;

	public EntityManager getEm() {
		return em;
	}
	public void setEm(EntityManager em) {
		this.em = em;
	}
	@Override
	public ArrayList<Hotel> fetchAllDetails() {
		ArrayList<Hotel> list= (ArrayList<Hotel>) em.createQuery("from Hotel",Hotel.class).getResultList(); 
		return list;
	}
	
}
