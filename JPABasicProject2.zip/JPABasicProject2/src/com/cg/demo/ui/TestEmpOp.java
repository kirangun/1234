package com.cg.demo.ui;

import com.cg.demo.bean.Student;
import com.cg.demo.service.StudentServiceImpl;

public class TestEmpOp {

	public static void main(String[] args) {

		StudentServiceImpl empserv = new StudentServiceImpl();
		Student e1 = new Student();
		e1.setStdName("Kirna");
		e1.setStdMarks(25);
		e1.setStdRollNO(25);
		empserv.addStudent(e1);

	}

}
