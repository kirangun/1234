package com.cg.demo.service;

import com.cg.demo.bean.Student;

public interface IStudentService {
	public Student addStudent(Student ee);
	public Student getStudent(int stdRollNo);
}
