package com.cg.demo.service;

import com.cg.demo.bean.Student;
import com.cg.demo.dao.IStudent;
import com.cg.demo.dao.StudentDaoImpl;

public class StudentServiceImpl implements IStudentService {
	IStudent stdDao=null;
	public StudentServiceImpl() {
		stdDao=new StudentDaoImpl();
	}
	@Override
	public Student addStudent(Student ee) {
		return stdDao.addEmp(ee);
	}

	@Override
	public Student getStudent(int stdRollNo) {
		// TODO Auto-generated method stub
		return null;
	}
	}


