package com.cg.demo.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity   				// specify that employee class is a JPA entity
@Table(name="Student1")	//Used if tableName and ClassName is different 
public class Student {
	
	@Id										//Mandatory annotation to map with primary column of database
	@Column(name="std_rollno",length=10)    	//Optional if both names are same.
	private int stdRollNO;
	@Column(name="std_name" ,length=20)
	private String stdName;
	@Column(name="std_marks",length=15)
	private float stdMarks;
	
	
	public int getStdRollNO() {
		return stdRollNO;
	}


	public void setStdRollNO(int stdRollNO) {
		this.stdRollNO = stdRollNO;
	}


	public String getStdName() {
		return stdName;
	}


	public void setStdName(String stdName) {
		this.stdName = stdName;
	}


	public float getStdMarks() {
		return stdMarks;
	}


	public void setStdMarks(float stdMarks) {
		this.stdMarks = stdMarks;
	}


	@Override
	public String toString() {
		return "Student [stdRollNO=" + stdRollNO + ", stdName=" + stdName + ", stdMarks=" + stdMarks + "]";
	}


	public Student() {
		super();
	}
	
	
	
	
}
