package com.cg.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.demo.bean.Student;
import com.cg.demo.util.JPAUtil;

public class StudentDaoImpl implements IStudent {

	EntityManager em=null;
	EntityTransaction trans= null;
	public StudentDaoImpl() {						/*Persist insert
													merge
													remove	find(based on primary column)*/	
	}
	@Override
	public Student addEmp(Student ee) {
		em=JPAUtil.getEntityManager();
		trans=em.getTransaction(); //get transcation 
		trans.begin();   //begin transcation
		em.persist(ee);
		trans.commit();
		System.out.println("Data is inserted in the table");
		Student e1=em.find(Student.class, ee.getStdRollNO());
		return e1;
	}
	

	@Override
	public Student getEmpByID(int empId) {
		return null;
	}

}

