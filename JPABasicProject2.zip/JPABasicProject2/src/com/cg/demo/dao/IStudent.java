package com.cg.demo.dao;

import com.cg.demo.bean.Student;

public interface IStudent {
		
	public Student addEmp(Student ee);
	public Student getEmpByID(int empId);
	

}
